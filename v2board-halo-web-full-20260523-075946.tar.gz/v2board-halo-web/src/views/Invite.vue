<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { fetchInviteApi } from '@/api/invite'
import CopyButton from '@/components/CopyButton.vue'

const data = ref<any>(null)
const error = ref('')

async function load() {
  try {
    const res = await fetchInviteApi()
    data.value = res.data
  } catch (e: any) {
    error.value = e.message || '邀请信息加载失败'
  }
}

onMounted(load)
</script>

<template>
  <div class="space-y-4">
    <section class="halo-card p-6">
      <div class="text-xs uppercase tracking-[0.26em] text-muted">Invite</div>
      <h1 class="mt-2 text-2xl font-semibold">邀请返利</h1>
    </section>

    <div v-if="error" class="rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta">{{ error }}</div>

    <section class="halo-card p-6">
      <pre class="overflow-auto text-sm text-muted">{{ data }}</pre>
      <div class="mt-4">
        <CopyButton :text="JSON.stringify(data)" />
      </div>
    </section>
  </div>
</template>
