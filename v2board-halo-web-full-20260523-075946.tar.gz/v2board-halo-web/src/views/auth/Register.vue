<script setup lang="ts">
import { ref } from 'vue'
import { RouterLink, useRouter } from 'vue-router'
import { registerApi } from '@/api/auth'
import { useAuthStore } from '@/stores/auth'
import { usePreferencesStore } from '@/stores/preferences'
import ThemeLangToggle from '@/components/ThemeLangToggle.vue'

const router = useRouter()
const auth = useAuthStore()
const preferences = usePreferencesStore()

const email = ref('')
const password = ref('')
const inviteCode = ref('')
const emailCode = ref('')
const loading = ref(false)
const error = ref('')
const success = ref('')

async function submit() {
  error.value = ''
  success.value = ''
  loading.value = true

  try {
    await registerApi({
      email: email.value,
      password: password.value,
      invite_code: inviteCode.value,
      email_code: emailCode.value
    })

    success.value = preferences.lang === 'zh' ? '注册成功，正在自动登录...' : 'Registered, signing in...'

    await auth.login(email.value, password.value)

    router.push('/dashboard')
  } catch (e: any) {
    error.value = e.message || (preferences.lang === 'zh' ? '注册失败' : 'Register failed')
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="flex min-h-screen items-center justify-center px-4 py-10">
    <div class="fixed right-4 top-4 z-50">
      <ThemeLangToggle />
    </div>

    <section class="halo-card w-full max-w-md p-6">
      <div class="mb-6">
        <div class="text-xs uppercase tracking-[0.26em] text-muted">Create Account</div>
        <h1 class="mt-2 text-2xl font-semibold">{{ preferences.t('createAccount') }}</h1>
      </div>

      <form class="space-y-4" @submit.prevent="submit">
        <input v-model="email" class="halo-input" type="email" :placeholder="preferences.t('email')" required />
        <input v-model="password" class="halo-input" type="password" :placeholder="preferences.t('password')" required />
        <input v-model="inviteCode" class="halo-input" :placeholder="preferences.t('inviteCode')" required />
        <input v-model="emailCode" class="halo-input" :placeholder="preferences.t('emailCode')" />

        <div v-if="error" class="rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta">
          {{ error }}
        </div>

        <div v-if="success" class="rounded-xl border border-lime/40 bg-lime/10 px-4 py-3 text-sm text-lime">
          {{ success }}
        </div>

        <button class="halo-btn halo-btn-primary w-full" :disabled="loading">
          {{ loading ? preferences.t('loading') + '...' : preferences.t('register') }}
        </button>
      </form>

      <RouterLink class="mt-5 block text-sm text-muted hover:text-onSurface" to="/login">
        {{ preferences.t('backLogin') }}
      </RouterLink>
    </section>
  </div>
</template>
