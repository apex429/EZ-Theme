<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import {
  fetchTicketsApi,
  saveTicketApi,
  replyTicketApi,
  closeTicketApi
} from '@/api/ticket'
import { formatDateTime } from '@/utils/format'
import { usePreferencesStore } from '@/stores/preferences'
import { Plus, Send, XCircle, MessageSquare } from 'lucide-vue-next'

const preferences = usePreferencesStore()

const tickets = ref<any[]>([])
const selected = ref<any | null>(null)
const loading = ref(false)
const error = ref('')
const message = ref('')

const showCreate = ref(false)
const newSubject = ref('')
const newMessage = ref('')
const newLevel = ref(0)

const replyMessage = ref('')

const ticketList = computed(() => {
  if (Array.isArray(tickets.value)) return tickets.value
  return []
})

function normalizeTickets(data: any) {
  if (Array.isArray(data)) return data
  if (Array.isArray(data?.data)) return data.data
  if (Array.isArray(data?.tickets)) return data.tickets
  return []
}

function normalizeDetail(item: any) {
  const messages = item?.message || item?.messages || item?.reply || item?.replies || []
  return {
    ...item,
    replies: Array.isArray(messages) ? messages : []
  }
}

async function loadTickets() {
  loading.value = true
  error.value = ''

  try {
    const res = await fetchTicketsApi()
    tickets.value = normalizeTickets(res.data)
    if (!selected.value && tickets.value.length) {
      selected.value = normalizeDetail(tickets.value[0])
    }
  } catch (e: any) {
    error.value = e.message || '工单加载失败'
  } finally {
    loading.value = false
  }
}

async function createTicket() {
  if (!newSubject.value || !newMessage.value) {
    message.value = preferences.lang === 'zh' ? '请填写标题和内容' : 'Please fill subject and message'
    return
  }

  loading.value = true
  message.value = ''

  try {
    await saveTicketApi({
      subject: newSubject.value,
      level: newLevel.value,
      message: newMessage.value
    })

    newSubject.value = ''
    newMessage.value = ''
    newLevel.value = 0
    showCreate.value = false

    message.value = preferences.lang === 'zh' ? '工单已创建' : 'Ticket created'
    await loadTickets()
  } catch (e: any) {
    message.value = e.message || '创建失败'
  } finally {
    loading.value = false
  }
}

async function replyTicket() {
  if (!selected.value?.id || !replyMessage.value) return

  loading.value = true
  message.value = ''

  try {
    await replyTicketApi({
      id: selected.value.id,
      message: replyMessage.value
    })

    replyMessage.value = ''
    message.value = preferences.lang === 'zh' ? '回复已发送' : 'Reply sent'
    await loadTickets()

    const updated = tickets.value.find(item => item.id === selected.value.id)
    if (updated) selected.value = normalizeDetail(updated)
  } catch (e: any) {
    message.value = e.message || '回复失败'
  } finally {
    loading.value = false
  }
}

async function closeTicket() {
  if (!selected.value?.id) return
  if (!confirm(preferences.lang === 'zh' ? '确定关闭该工单？' : 'Close this ticket?')) return

  loading.value = true
  message.value = ''

  try {
    await closeTicketApi({ id: selected.value.id })
    message.value = preferences.lang === 'zh' ? '工单已关闭' : 'Ticket closed'
    await loadTickets()
  } catch (e: any) {
    message.value = e.message || '关闭失败'
  } finally {
    loading.value = false
  }
}

function selectTicket(item: any) {
  selected.value = normalizeDetail(item)
}

function statusText(status: any) {
  if (status === 0 || status === '0') return preferences.lang === 'zh' ? '待处理' : 'Pending'
  if (status === 1 || status === '1') return preferences.lang === 'zh' ? '已回复' : 'Replied'
  if (status === 2 || status === '2') return preferences.lang === 'zh' ? '已关闭' : 'Closed'
  return String(status ?? '-')
}

onMounted(loadTickets)
</script>

<template>
  <div class="space-y-4">
    <section class="halo-card p-4 lg:p-6">
      <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div class="text-[10px] uppercase tracking-[0.26em] text-muted">Tickets</div>
          <h1 class="mt-1 text-xl font-semibold">
            {{ preferences.lang === 'zh' ? '工单中心' : 'Ticket Center' }}
          </h1>
        </div>

        <button class="halo-btn halo-btn-primary" @click="showCreate = !showCreate">
          <Plus :size="16" />
          {{ preferences.lang === 'zh' ? '创建工单' : 'New Ticket' }}
        </button>
      </div>

      <div v-if="message" class="mt-4 rounded-xl border border-indigo/40 bg-indigo/10 px-4 py-3 text-sm text-indigo">
        {{ message }}
      </div>

      <div v-if="error" class="mt-4 rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta">
        {{ error }}
      </div>
    </section>

    <section v-if="showCreate" class="halo-card p-4 lg:p-6">
      <h2 class="text-lg font-semibold">
        {{ preferences.lang === 'zh' ? '创建新工单' : 'Create Ticket' }}
      </h2>

      <div class="mt-4 grid gap-3">
        <input
          v-model="newSubject"
          class="halo-input"
          :placeholder="preferences.lang === 'zh' ? '工单标题' : 'Subject'"
        />

        <select v-model="newLevel" class="halo-input">
          <option :value="0">{{ preferences.lang === 'zh' ? '普通' : 'Normal' }}</option>
          <option :value="1">{{ preferences.lang === 'zh' ? '重要' : 'Important' }}</option>
          <option :value="2">{{ preferences.lang === 'zh' ? '紧急' : 'Urgent' }}</option>
        </select>

        <textarea
          v-model="newMessage"
          class="min-h-[120px] rounded-xl border border-border bg-canvas/60 p-3 text-sm outline-none focus:border-indigo"
          :placeholder="preferences.lang === 'zh' ? '请描述你的问题' : 'Describe your issue'"
        ></textarea>

        <button class="halo-btn halo-btn-primary justify-self-start" :disabled="loading" @click="createTicket">
          <Send :size="16" />
          {{ loading ? preferences.t('loading') + '...' : preferences.lang === 'zh' ? '提交工单' : 'Submit' }}
        </button>
      </div>
    </section>

    <section class="grid gap-4 lg:grid-cols-[360px_1fr]">
      <!-- 历史工单 -->
      <div class="halo-card overflow-hidden">
        <div class="border-b border-border p-4">
          <h2 class="font-semibold">
            {{ preferences.lang === 'zh' ? '历史工单' : 'Ticket History' }}
          </h2>
        </div>

        <div class="max-h-[620px] overflow-y-auto">
          <button
            v-for="item in ticketList"
            :key="item.id"
            class="block w-full border-b border-border/60 p-4 text-left transition hover:bg-white/5"
            :class="selected?.id === item.id ? 'bg-indigo/10' : ''"
            @click="selectTicket(item)"
          >
            <div class="flex items-center justify-between gap-3">
              <div class="truncate font-medium">
                {{ item.subject || item.title || 'Ticket #' + item.id }}
              </div>
              <span class="rounded-full border border-border px-2 py-0.5 text-[10px] text-muted">
                {{ statusText(item.status) }}
              </span>
            </div>

            <div class="mt-2 flex items-center justify-between text-xs text-muted">
              <span>#{{ item.id }}</span>
              <span>{{ formatDateTime(item.created_at) }}</span>
            </div>
          </button>

          <div v-if="!ticketList.length" class="p-6 text-center text-sm text-muted">
            {{ preferences.lang === 'zh' ? '暂无工单' : 'No tickets' }}
          </div>
        </div>
      </div>

      <!-- 工单详情 -->
      <div class="halo-card p-4 lg:p-6">
        <template v-if="selected">
          <div class="flex flex-col gap-3 border-b border-border pb-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div class="text-xs text-muted">#{{ selected.id }}</div>
              <h2 class="mt-1 text-lg font-semibold">
                {{ selected.subject || selected.title || 'Ticket #' + selected.id }}
              </h2>
            </div>

            <button class="halo-btn halo-btn-ghost text-sm" @click="closeTicket">
              <XCircle :size="16" />
              {{ preferences.lang === 'zh' ? '关闭工单' : 'Close' }}
            </button>
          </div>

          <div class="mt-4 space-y-3">
            <div class="rounded-2xl border border-border bg-canvas/50 p-4">
              <div class="mb-2 flex items-center gap-2 text-xs text-muted">
                <MessageSquare :size="14" />
                {{ preferences.lang === 'zh' ? '工单内容' : 'Message' }}
              </div>
              <div class="whitespace-pre-wrap text-sm leading-7">
                {{ selected.message || selected.content || selected.body || '-' }}
              </div>
            </div>

            <div
              v-for="reply in selected.replies"
              :key="reply.id || reply.created_at || reply.message"
              class="rounded-2xl border border-border bg-elevated/40 p-4"
            >
              <div class="mb-2 flex justify-between text-xs text-muted">
                <span>{{ reply.is_admin ? 'Admin' : 'User' }}</span>
                <span>{{ formatDateTime(reply.created_at) }}</span>
              </div>
              <div class="whitespace-pre-wrap text-sm leading-7">
                {{ reply.message || reply.content }}
              </div>
            </div>
          </div>

          <div class="mt-5">
            <textarea
              v-model="replyMessage"
              class="min-h-[120px] w-full rounded-xl border border-border bg-canvas/60 p-3 text-sm outline-none focus:border-indigo"
              :placeholder="preferences.lang === 'zh' ? '输入回复内容' : 'Write a reply'"
            ></textarea>

            <button class="halo-btn halo-btn-primary mt-3" :disabled="loading" @click="replyTicket">
              <Send :size="16" />
              {{ loading ? preferences.t('loading') + '...' : preferences.lang === 'zh' ? '发送回复' : 'Send Reply' }}
            </button>
          </div>
        </template>

        <div v-else class="flex min-h-[360px] items-center justify-center text-muted">
          {{ preferences.lang === 'zh' ? '请选择一个工单' : 'Select a ticket' }}
        </div>
      </div>
    </section>
  </div>
</template>
