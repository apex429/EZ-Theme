<script setup lang="ts">
import { onMounted } from 'vue'
import SupportWidget from '@/components/SupportWidget.vue'
import PageLoader from '@/components/PageLoader.vue'
import { usePreferencesStore } from '@/stores/preferences'

const preferences = usePreferencesStore()

onMounted(() => {
  preferences.init()
})
</script>

<template>
  <RouterView />

  <PageLoader />
  <SupportWidget />
</template>
