import { http, type ApiResp } from './http'
export function fetchInviteApi() {
  return http.get<any, ApiResp<any>>('/api/v1/user/invite/fetch')
}
