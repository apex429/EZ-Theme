<script setup lang="ts">
import { computed, onMounted, onBeforeUnmount, ref, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import {
  LayoutDashboard, Radio, Package, Server, Receipt, MessageSquare,
  BookOpen, Gift, Wallet, Settings, LogOut, Menu, X, Upload, Download, CalendarDays
} from 'lucide-vue-next'
import { useAuthStore } from '@/stores/auth'
import { useUserStore } from '@/stores/user'
import { usePreferencesStore } from '@/stores/preferences'
import ThemeLangToggle from '@/components/ThemeLangToggle.vue'
import { formatDate } from '@/utils/format'
import { formatTraffic, getTrafficPercent, getUsedTraffic } from '@/utils/traffic'

const router = useRouter()
const route = useRoute()
const auth = useAuthStore()
const user = useUserStore()
const preferences = usePreferencesStore()
const logoText = import.meta.env.VITE_APP_LOGO_TEXT || 'Cloud'
const mobileMenuOpen = ref(false)

const headerUpload = computed(() => formatTraffic(user.subscribe?.u || 0))
const headerDownload = computed(() => formatTraffic(user.subscribe?.d || 0))
const headerExpire = computed(() => formatDate(user.subscribe?.expired_at || user.info?.expired_at))
const headerUsedRaw = computed(() => getUsedTraffic(user.subscribe?.u, user.subscribe?.d))
const headerTotalRaw = computed(() => Number(user.subscribe?.transfer_enable || user.info?.transfer_enable || 0))
const headerUsed = computed(() => formatTraffic(headerUsedRaw.value))
const headerTotal = computed(() => formatTraffic(headerTotalRaw.value))
const headerPercent = computed(() => getTrafficPercent(headerUsedRaw.value, headerTotalRaw.value))
const showConsoleHeader = computed(() => ['/dashboard', '/subscribe'].includes(route.path))
const showTrafficHeader = computed(() => ['/dashboard', '/subscribe'].includes(route.path))




const menus = [
  { path: '/dashboard', labelKey: 'dashboard', icon: LayoutDashboard },
  { path: '/subscribe', labelKey: 'subscribe', icon: Radio },
  { path: '/plans', labelKey: 'plans', icon: Package },
  { path: '/nodes', labelKey: 'nodes', icon: Server },
  { path: '/orders', labelKey: 'orders', icon: Receipt },
  { path: '/tickets', labelKey: 'tickets', icon: MessageSquare },
  { path: '/knowledge', labelKey: 'knowledge', icon: BookOpen },
  { path: '/invite', labelKey: 'invite', icon: Gift },
  { path: '/wallet', labelKey: 'wallet', icon: Wallet },
  { path: '/settings', labelKey: 'settings', icon: Settings }
]

function logout() {
  auth.logout()
  router.push('/login')
}

function closeMobileMenu() {
  mobileMenuOpen.value = false
  document.body.style.overflow = ''
  document.documentElement.style.overflow = ''
}

watch(() => route.path, () => {
  mobileMenuOpen.value = false
  document.body.style.overflow = ''
  document.documentElement.style.overflow = ''
})

watch(mobileMenuOpen, (open) => {
  if (open) {
    document.body.style.overflow = 'hidden'
    document.documentElement.style.overflow = 'hidden'
  } else {
    document.body.style.overflow = ''
    document.documentElement.style.overflow = ''
  }
})

onMounted(() => user.fetchUser())

onBeforeUnmount(() => {
  document.body.style.overflow = ''
  document.documentElement.style.overflow = ''
})
</script>

<template>
  <div class="min-h-screen">
    <!-- 移动端顶部导航 -->
    <header class="sticky top-0 z-50 flex items-center justify-between border-b border-border/80 bg-surface/98 px-4 py-3 backdrop-blur-xl lg:hidden">
      <div class="flex items-center gap-2.5">
        <div class="h-7 w-7 rounded-lg bg-gradient-to-br from-indigo to-cyan shadow-glow"></div>
        <div class="text-sm font-semibold">{{ logoText }}</div>
      </div>
      <div class="flex items-center gap-2">
        <ThemeLangToggle />
        <button 
          class="rounded-lg p-2 transition hover:bg-white/5 active:scale-95" 
          @click="mobileMenuOpen = !mobileMenuOpen"
        >
          <Menu v-if="!mobileMenuOpen" :size="22" />
          <X v-else :size="22" />
        </button>
      </div>
    </header>

    <!-- 移动端侧边栏遮罩 -->
    <Transition
      enter-active-class="transition-opacity duration-200"
      leave-active-class="transition-opacity duration-200"
      enter-from-class="opacity-0"
      leave-to-class="opacity-0"
    >
      <div
        v-if="mobileMenuOpen"
        class="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden"
        @click="closeMobileMenu"
      ></div>
    </Transition>

    <!-- 移动端侧边栏 -->
    <Transition
      enter-active-class="transition-transform duration-300 ease-out"
      leave-active-class="transition-transform duration-250 ease-in"
      enter-from-class="-translate-x-full"
      leave-to-class="-translate-x-full"
    >
      <aside
        v-if="mobileMenuOpen"
        class="fixed inset-y-0 left-0 z-50 flex w-[280px] flex-col border-r border-border/80 bg-surface p-4 shadow-2xl lg:hidden"
      >
        <div class="flex items-center justify-between border-b border-border/80 pb-4">
          <div class="flex items-center gap-2.5">
            <div class="h-9 w-9 rounded-xl bg-gradient-to-br from-indigo to-cyan shadow-glow"></div>
            <div>
              <div class="font-semibold">{{ logoText }}</div>
              <div class="mono text-[10px] text-muted">v2board · halo</div>
            </div>
          </div>
          <button class="rounded-lg p-1.5 transition hover:bg-white/5 active:scale-95" @click="closeMobileMenu">
            <X :size="20" />
          </button>
        </div>

        <nav class="mt-4 flex-1 space-y-1 overflow-y-auto">
          <RouterLink
            v-for="(item, index) in menus"
            :key="item.path"
            :to="item.path"
            :style="{ animationDelay: (index * 0.05) + 's' }"
            class="menu-item flex items-center gap-3 rounded-xl px-3 py-3 text-sm transition active:scale-[0.98]"
            :class="route.path === item.path 
              ? 'bg-indigo/15 text-onSurface border border-indigo/30' 
              : 'text-muted hover:bg-white/5 hover:text-onSurface'"
          >
            <component :is="item.icon" :size="19" />
            {{ preferences.t(item.labelKey as any) }}
          </RouterLink>
        </nav>

        <div class="border-t border-border/80 pt-4">
          <div class="rounded-xl border border-border bg-elevated/60 p-3.5">
            <div class="truncate text-sm font-medium">{{ user.info?.email || 'Loading...' }}</div>
            <div class="mt-1 text-xs text-muted">Cloud Account</div>
          </div>
          <button class="halo-btn halo-btn-ghost mt-3 w-full active:scale-[0.98]" @click="logout">
            <LogOut :size="16" />
            退出登录
          </button>
        </div>
      </aside>
    </Transition>

    <div class="lg:flex lg:gap-4 lg:p-4">
      <!-- 桌面端侧边栏 -->
      <aside class="sticky top-4 hidden h-[calc(100vh-32px)] w-[240px] shrink-0 lg:block">
        <div class="halo-card flex h-full flex-col p-4">
          <div class="flex items-center gap-2.5 border-b border-border/80 pb-4">
            <div class="h-8 w-8 rounded-lg bg-gradient-to-br from-indigo to-cyan shadow-glow"></div>
            <div>
              <div class="text-sm font-semibold">{{ logoText }}</div>
              <div class="mono text-[10px] text-muted">v2board · halo</div>
            </div>
          </div>

          <div class="mt-3 border-b border-border/80 pb-4">
            <ThemeLangToggle />
          </div>

          <nav class="mt-4 flex-1 space-y-0.5 overflow-y-auto">
            <RouterLink
              v-for="(item, index) in menus"
              :key="item.path"
              :to="item.path"
              :style="{ animationDelay: (index * 0.05) + 's' }"
              class="menu-item flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm text-muted transition hover:bg-white/5 hover:text-onSurface"
              :class="route.path === item.path ? 'bg-white/10 text-onSurface border border-border' : ''"
            >
              <component :is="item.icon" :size="16" />
              {{ preferences.t(item.labelKey as any) }}
            </RouterLink>
          </nav>

          <div class="border-t border-border/80 pt-4">
            <div class="rounded-lg border border-border bg-elevated/50 p-3">
              <div class="truncate text-xs">{{ user.info?.email || 'Loading...' }}</div>
              <div class="mt-0.5 text-[10px] text-muted">Cloud Account</div>
            </div>
            <button class="halo-btn halo-btn-ghost mt-2.5 w-full text-sm" @click="logout">
              <LogOut :size="14" />
              退出
            </button>
          </div>
        </div>
      </aside>

      <!-- 主内容区 -->
      <main class="min-w-0 flex-1 p-3 pb-6 lg:p-0">
        <header v-if="showConsoleHeader" class="halo-card mb-3 overflow-visible p-4 lg:mb-4">
          <div class="grid gap-3 lg:grid-cols-[1fr_132px] lg:items-center">
            <!-- 左侧：标题 + 紧凑流量条 -->
            <div class="min-w-0">
              <div class="flex items-start justify-between gap-3">
                <div>
                  <div class="text-[10px] uppercase tracking-[0.26em] text-muted">
                    {{ preferences.t('workspace') }}
                  </div>
                  <h1 class="mt-1 text-lg font-semibold sm:text-xl lg:text-2xl">
                    {{ preferences.t('cloudConsole') }}
                  </h1>
                </div>

                <div class="hidden sm:block lg:hidden">
                  <ThemeLangToggle />
                </div>
              </div>

              <!-- 超紧凑流量消耗条 -->
              <div v-if="showTrafficHeader" class="mt-3 rounded-xl border border-border bg-elevated/40 px-3 py-2.5">
                <div class="mb-2 flex items-center justify-between gap-3">
                  <div class="mono truncate text-xs text-onSurface sm:text-sm">
                    {{ headerUsed }} / {{ headerTotal }}
                  </div>

                  <div class="mono shrink-0 rounded-full bg-canvas/60 px-2 py-0.5 text-[10px] text-cyan sm:text-xs">
                    {{ headerPercent.toFixed(1) }}%
                  </div>
                </div>

                <div class="h-2 overflow-hidden rounded-full bg-canvas/70">
                  <div
                    class="traffic-bar h-full rounded-full bg-gradient-to-r from-indigo via-cyan to-lime"
                    :style="{ width: headerPercent + '%' }"
                  ></div>
                </div>

                <div class="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-muted sm:text-xs">
                  <div class="flex items-center gap-1.5">
                    <Upload :size="13" class="text-indigo" />
                    <span class="mono text-indigo">{{ headerUpload }}</span>
                  </div>

                  <div class="flex items-center gap-1.5">
                    <Download :size="13" class="text-cyan" />
                    <span class="mono text-cyan">{{ headerDownload }}</span>
                  </div>

                  <div class="flex items-center gap-1.5">
                    <CalendarDays :size="13" class="text-amber" />
                    <span class="mono text-amber">{{ headerExpire }}</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- 右侧：主题语言 + 上下按钮 -->
            <div class="flex flex-col gap-2 lg:w-[132px]">
              <div class="hidden lg:block">
                <ThemeLangToggle />
              </div>

              <RouterLink
                to="/plans"
                class="halo-btn halo-btn-primary h-10 w-full text-sm"
              >
                {{ preferences.t('buyPlan') }}
              </RouterLink>

              <RouterLink
                to="/subscribe"
                class="halo-btn halo-btn-ghost h-10 w-full text-sm"
              >
                {{ preferences.t('mySubscribe') }}
              </RouterLink>
            </div>
          </div>
        </header>

        <RouterView v-slot="{ Component, route }">
          <Transition name="page" mode="out-in">
            <component :is="Component" :key="route.path" />
          </Transition>
        </RouterView>
      </main>
    </div>
  </div>
</template>
