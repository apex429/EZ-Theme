import { http, type ApiResp } from './http'

export function fetchOrdersApi(params?: Record<string, any>) {
  return http.get<any, ApiResp<any>>('/api/v1/user/order/fetch', { params })
}

export function saveOrderApi(data: Record<string, any>) {
  return http.post<any, ApiResp<any>>('/api/v1/user/order/save', data)
}

export function checkoutOrderApi(data: Record<string, any>) {
  return http.post<any, ApiResp<any>>('/api/v1/user/order/checkout', data)
}

export function cancelOrderApi(data: { trade_no: string }) {
  return http.post<any, ApiResp<any>>('/api/v1/user/order/cancel', data)
}

export function getPaymentMethodApi() {
  return http.get<any, ApiResp<any>>('/api/v1/user/order/getPaymentMethod')
}

export function checkCouponApi(data: Record<string, any>) {
  return http.post<any, ApiResp<any>>('/api/v1/user/coupon/check', data)
}
