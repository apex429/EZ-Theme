import { http, type ApiResp } from './http'

export function fetchInviteApi() {
  return http.get<any, ApiResp<any>>('/api/v1/user/invite/fetch')
}

// 你的版本创建邀请码是 GET
export function saveInviteApi() {
  return http.get<any, ApiResp<any>>('/api/v1/user/invite/save')
}

export function fetchCommissionApi(params?: Record<string, any>) {
  return http.get<any, ApiResp<any>>('/api/v1/user/commission/fetch', { params })
}

// 你的后端实际可用接口：POST /api/v1/user/transfer
// 通常 transfer_amount 单位是“分”，所以前端会把元 * 100
export function transferCommissionApi(data: {
  transfer_amount: number
  amount?: number
}) {
  return http.post<any, ApiResp<any>>('/api/v1/user/transfer', data)
}

export function withdrawCommissionApi(data: Record<string, any>) {
  return http.post<any, ApiResp<any>>('/api/v1/user/commission/withdraw', data)
}


export async function removeInviteApi(invite: any) {
  const payload = {
    id: invite?.id,
    code: invite?.code || invite?.invite_code || invite?.inviteCode
  }

  const attempts = [
    () => http.post<any, ApiResp<any>>('/api/v1/user/invite/remove', payload),
    () => http.get<any, ApiResp<any>>('/api/v1/user/invite/remove', { params: payload }),
    () => http.post<any, ApiResp<any>>('/api/v1/user/invite/delete', payload),
    () => http.get<any, ApiResp<any>>('/api/v1/user/invite/delete', { params: payload })
  ]

  let lastError: any = null

  for (const run of attempts) {
    try {
      return await run()
    } catch (e) {
      lastError = e
    }
  }

  throw lastError || new Error('Remove invite failed')
}
