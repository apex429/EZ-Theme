import { http, type ApiResp } from './http'
export function fetchKnowledgeApi(params?: Record<string, any>) {
  return http.get<any, ApiResp<any>>('/api/v1/user/knowledge/fetch', { params })
}
