import { http, type ApiResp } from './http'
export function fetchServersApi() {
  return http.get<any, ApiResp<any>>('/api/v1/user/server/fetch')
}
