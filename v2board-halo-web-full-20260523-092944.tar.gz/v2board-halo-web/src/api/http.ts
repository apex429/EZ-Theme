import axios, { AxiosError } from 'axios'
import { siteConfig } from '@/config/site'

export interface ApiResp<T = any> {
  data: T
  message?: string
  status?: string | number
}

export const http = axios.create({
  baseURL: siteConfig.apiBaseUrl || import.meta.env.VITE_API_BASE_URL,
  timeout: 20000,
  headers: {
    'Content-Type': 'application/json'
  }
})

http.interceptors.request.use((config) => {
  const authData = localStorage.getItem('auth_data')
  const token = localStorage.getItem('token')

  if (authData || token) {
    config.headers.Authorization = authData || token
  }

  return config
})

http.interceptors.response.use(
  (response) => response.data,
  (error: AxiosError<any>) => {
    const status = error.response?.status
    const message =
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.message ||
      '请求失败'

    if (status === 401 || status === 403) {
      localStorage.removeItem('token')
      localStorage.removeItem('auth_data')
      localStorage.removeItem('is_admin')

      if (!location.pathname.includes('/login')) {
        location.href = '/login'
      }
    }

    return Promise.reject(new Error(message))
  }
)
