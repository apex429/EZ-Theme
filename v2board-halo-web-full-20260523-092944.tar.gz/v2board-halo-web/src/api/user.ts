import { http, type ApiResp } from './http'

export interface UserInfo {
  email?: string
  transfer_enable?: number
  last_login_at?: number
  created_at?: number
  expired_at?: number | null
  balance?: number
  commission_balance?: number
  plan_id?: number | null
  uuid?: string
  [key: string]: any
}

export interface SubscribeInfo {
  plan_id?: number
  token?: string
  expired_at?: number | null
  u?: number
  d?: number
  transfer_enable?: number
  email?: string
  uuid?: string
  subscribe_url?: string
  reset_day?: number
  [key: string]: any
}

export function getUserInfoApi() {
  return http.get<any, ApiResp<UserInfo>>('/api/v1/user/info')
}

export function getSubscribeApi() {
  return http.get<any, ApiResp<SubscribeInfo>>('/api/v1/user/getSubscribe')
}

export function resetSecurityApi() {
  return http.get<any, ApiResp<any>>('/api/v1/user/resetSecurity')
}


export function getStatApi() {
  return http.get<any, ApiResp<any>>('/api/v1/user/getStat')
}
