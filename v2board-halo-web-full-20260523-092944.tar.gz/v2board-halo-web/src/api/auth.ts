import { http, type ApiResp } from './http'

export interface LoginResult {
  token: string
  is_admin: number
  auth_data: string
}

export function loginApi(data: { email: string; password: string }) {
  return http.post<any, ApiResp<LoginResult>>('/api/v1/passport/auth/login', data)
}

export function registerApi(data: {
  email: string
  password: string
  invite_code?: string
  email_code?: string
}) {
  return http.post<any, ApiResp<any>>('/api/v1/passport/auth/register', data)
}

export function forgotApi(data: { email: string }) {
  return http.post<any, ApiResp<any>>('/api/v1/passport/auth/forget', data)
}
