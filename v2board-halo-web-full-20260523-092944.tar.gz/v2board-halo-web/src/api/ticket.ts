import { http, type ApiResp } from './http'

export function fetchTicketsApi(params?: Record<string, any>) {
  return http.get<any, ApiResp<any>>('/api/v1/user/ticket/fetch', { params })
}

export function fetchTicketDetailApi(id: number) {
  return http.get<any, ApiResp<any>>('/api/v1/user/ticket/fetch', {
    params: { id }
  })
}

export function saveTicketApi(data: {
  subject: string
  level?: number
  message: string
}) {
  return http.post<any, ApiResp<any>>('/api/v1/user/ticket/save', data)
}

export function replyTicketApi(data: {
  id: number
  message: string
}) {
  return http.post<any, ApiResp<any>>('/api/v1/user/ticket/reply', data)
}

export function closeTicketApi(data: {
  id: number
}) {
  return http.post<any, ApiResp<any>>('/api/v1/user/ticket/close', data)
}
