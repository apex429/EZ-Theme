import { http, type ApiResp } from './http'

export function fetchNoticeApi() {
  return http.get<any, ApiResp<any>>('/api/v1/user/notice/fetch')
}
