import { http, type ApiResp } from './http'

export interface Plan {
  id: number
  name: string
  transfer_enable: number
  speed_limit?: number | null
  content?: string
  month_price?: number | null
  quarter_price?: number | null
  half_year_price?: number | null
  year_price?: number | null
  onetime_price?: number | null
  [key: string]: any
}

export function fetchPlansApi() {
  return http.get<any, ApiResp<Plan[]>>('/api/v1/user/plan/fetch')
}
