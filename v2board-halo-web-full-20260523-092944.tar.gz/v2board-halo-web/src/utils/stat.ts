export interface DailyTrafficItem {
  date: string
  upload: number
  download: number
}

function pickArray(data: any): any[] {
  if (Array.isArray(data)) return data
  if (Array.isArray(data?.data)) return data.data
  if (Array.isArray(data?.stats)) return data.stats
  if (Array.isArray(data?.record)) return data.record
  if (Array.isArray(data?.records)) return data.records
  if (Array.isArray(data?.traffic)) return data.traffic
  if (Array.isArray(data?.stat)) return data.stat
  return []
}

function formatDateFromAny(item: any, index: number) {
  const raw =
    item.date ||
    item.day ||
    item.created_at ||
    item.record_at ||
    item.timestamp ||
    item.time

  if (!raw) {
    const d = new Date()
    d.setDate(d.getDate() - (6 - index))
    return d.toISOString().slice(0, 10)
  }

  if (typeof raw === 'number') {
    return new Date(raw * 1000).toISOString().slice(0, 10)
  }

  return String(raw).slice(0, 10)
}

export function normalizeDailyTraffic(data: any): DailyTrafficItem[] {
  const arr = pickArray(data)

  return arr.map((item, index) => {
    const upload =
      Number(item.u ?? item.upload ?? item.up ?? item.upload_traffic ?? item.uploadTraffic ?? 0)

    const download =
      Number(item.d ?? item.download ?? item.down ?? item.download_traffic ?? item.downloadTraffic ?? 0)

    return {
      date: formatDateFromAny(item, index),
      upload,
      download
    }
  }).filter(item => item.upload > 0 || item.download > 0)
}
