export function formatTraffic(bytes?: number | null) {
  const value = Number(bytes || 0)
  if (value <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
  const index = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1)
  return `${(value / Math.pow(1024, index)).toFixed(index === 0 ? 0 : 2)} ${units[index]}`
}

export function getUsedTraffic(u?: number, d?: number) {
  return Number(u || 0) + Number(d || 0)
}

export function getTrafficPercent(used?: number, total?: number) {
  const u = Number(used || 0)
  const t = Number(total || 0)
  if (!t) return 0
  return Math.min(100, Math.max(0, (u / t) * 100))
}
