import dayjs from 'dayjs'

export function formatDate(timestamp?: number | null) {
  if (!timestamp) return '长期有效'
  return dayjs(timestamp * 1000).format('YYYY-MM-DD')
}

export function formatDateTime(timestamp?: number | null) {
  if (!timestamp) return '-'
  return dayjs(timestamp * 1000).format('YYYY-MM-DD HH:mm')
}

export function formatMoney(value?: number | string | null) {
  const num = Number(value || 0) / 100
  return `¥${num.toFixed(2)}`
}
