<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { resetSecurityApi } from '@/api/user'
import { useUserStore } from '@/stores/user'
import { formatTraffic, getTrafficPercent, getUsedTraffic } from '@/utils/traffic'
import CopyButton from '@/components/CopyButton.vue'
import { usePreferencesStore } from '@/stores/preferences'
import { useFeedbackStore } from '@/stores/feedback'

const user = useUserStore()
const preferences = usePreferencesStore()
const feedback = useFeedbackStore()

const loading = ref(false)
const message = ref('')

const used = computed(() => getUsedTraffic(user.subscribe?.u, user.subscribe?.d))
const total = computed(() => Number(user.subscribe?.transfer_enable || user.info?.transfer_enable || 0))
const percent = computed(() => getTrafficPercent(used.value, total.value))
const subscribeUrl = computed(() => user.subscribe?.subscribe_url || '')

const clients = [
  { name: 'Clash', icon: '⚡', url: 'clash://install-config?url=' },
  { name: 'V2rayN', icon: '🚀', url: 'v2rayn://install-config?url=' },
  { name: 'Shadowrocket', icon: '🔥', url: 'shadowrocket://add/sub://' },
  { name: 'Surge', icon: '🌊', url: 'surge:///install-config?url=' },
  { name: 'Quantumult X', icon: '⚛️', url: 'quantumult-x:///add-resource?remote-resource=' }
]

const dailyTraffic = ref([
  { date: '2026-05-17', upload: 236000000, download: 1280000000 },
  { date: '2026-05-18', upload: 418000000, download: 2360000000 },
  { date: '2026-05-19', upload: 328000000, download: 1840000000 },
  { date: '2026-05-20', upload: 520000000, download: 3100000000 },
  { date: '2026-05-21', upload: 295000000, download: 1560000000 },
  { date: '2026-05-22', upload: 610000000, download: 4280000000 },
  { date: '2026-05-23', upload: 386000000, download: 2680000000 }
])

const dailyMax = computed(() => {
  const totals = dailyTraffic.value.map(item => item.upload + item.download)
  return Math.max(...totals, 1)
})

const dailyTotal = computed(() => {
  return dailyTraffic.value.reduce((sum, item) => sum + item.upload + item.download, 0)
})

function openClient(client: typeof clients[0]) {
  if (!subscribeUrl.value) {
    message.value = preferences.t('noSubscribe')
    return
  }

  const encoded = encodeURIComponent(subscribeUrl.value)
  window.location.href = client.url + encoded
}

async function resetSub() {
  const ok = await feedback.confirm({
    title: preferences.lang === 'zh' ? '重置订阅链接' : 'Reset Subscription',
    message: preferences.lang === 'zh' ? '确定要重置订阅链接吗？旧链接将失效。' : 'Reset subscription URL? Old URL will be invalid.',
    confirmText: preferences.lang === 'zh' ? '确认重置' : 'Reset',
    cancelText: preferences.lang === 'zh' ? '取消' : 'Cancel'
  })
  if (!ok) return

  loading.value = true
  message.value = ''

  try {
    await resetSecurityApi()
    await user.fetchUser()
    message.value = preferences.lang === 'zh' ? '订阅链接已重置' : 'Subscription URL has been reset'
    feedback.success(message.value)
  } catch (e: any) {
    message.value = e.message || (preferences.lang === 'zh' ? '重置失败' : 'Reset failed')
  } finally {
    loading.value = false
  }
}

onMounted(() => user.fetchUser())
</script>

<template>
  <div class="space-y-3 lg:space-y-4">
    <!-- 订阅链接与一键导入 -->
    <section class="halo-card p-4 lg:p-6">
      <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <div class="text-[10px] uppercase tracking-[0.26em] text-muted">Subscription</div>
          <h1 class="mt-1 text-lg font-semibold lg:text-2xl">
            {{ preferences.t('subscription') }}
          </h1>
        </div>

        <div class="flex gap-2">
          <CopyButton :text="subscribeUrl" />
          <button
            class="halo-btn halo-btn-ghost text-xs sm:text-sm"
            :disabled="loading"
            @click="resetSub"
          >
            {{ loading ? preferences.t('loading') + '...' : preferences.t('resetSubscribe') }}
          </button>
        </div>
      </div>

      <div class="mt-4 rounded-2xl border border-border bg-canvas/50 p-3 lg:mt-6 lg:p-4">
        <div class="break-all text-[11px] leading-relaxed text-muted sm:text-xs">
          {{ subscribeUrl || preferences.t('noSubscribe') }}
        </div>
      </div>

      <div
        v-if="message"
        class="mt-3 rounded-xl border border-indigo/40 bg-indigo/10 px-4 py-3 text-sm text-indigo lg:mt-4"
      >
        {{ message }}
      </div>

      <div class="mt-4 lg:mt-5">
        <div class="mb-2 text-xs font-medium text-muted">
          {{ preferences.t('importClient') }}
        </div>

        <div class="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
          <button
            v-for="client in clients"
            :key="client.name"
            class="halo-btn halo-btn-ghost flex-col gap-1.5 py-3"
            @click="openClient(client)"
          >
            <span class="text-2xl">{{ client.icon }}</span>
            <span class="text-xs">{{ client.name }}</span>
          </button>
        </div>
      </div>
    </section>

    <!-- 总流量概览 -->
    <section class="halo-card p-4 lg:p-6">
      <div class="mb-2 flex justify-between text-xs sm:text-sm">
        <span class="text-muted">
          {{ preferences.t('usedTraffic') }}
        </span>
        <span class="mono text-[11px] sm:text-xs">
          {{ formatTraffic(used) }} / {{ formatTraffic(total) }}
        </span>
      </div>

      <div class="h-3 overflow-hidden rounded-full bg-elevated">
        <div
          class="traffic-bar h-full rounded-full bg-gradient-to-r from-indigo to-cyan"
          :style="{ width: percent + '%' }"
        ></div>
      </div>
    </section>

    <!-- 每日流量明细 -->
    <section class="halo-card p-4 lg:p-6">
      <div class="mb-5 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div class="text-[10px] uppercase tracking-[0.26em] text-muted">Daily Traffic</div>
          <h2 class="mt-1 text-lg font-semibold lg:text-xl">
            {{ preferences.lang === 'zh' ? '每日流量明细' : 'Daily Traffic Details' }}
          </h2>
        </div>

        <div class="rounded-full border border-border bg-elevated/60 px-3 py-1.5 text-xs text-muted">
          {{ preferences.lang === 'zh' ? '近 7 天合计' : 'Last 7 days' }}
          <span class="mono text-onSurface">{{ formatTraffic(dailyTotal) }}</span>
        </div>
      </div>

      <!-- 移动端卡片 -->
      <div class="space-y-3 md:hidden">
        <div
          v-for="item in dailyTraffic"
          :key="item.date"
          class="rounded-2xl border border-border bg-canvas/40 p-3"
        >
          <div class="mb-3 flex items-center justify-between">
            <div class="mono text-xs text-muted">{{ item.date }}</div>
            <div class="mono text-sm font-semibold">
              {{ formatTraffic(item.upload + item.download) }}
            </div>
          </div>

          <div class="mb-2 h-2 overflow-hidden rounded-full bg-elevated">
            <div
              class="h-full rounded-full bg-gradient-to-r from-indigo to-cyan"
              :style="{ width: ((item.upload + item.download) / dailyMax * 100) + '%' }"
            ></div>
          </div>

          <div class="grid grid-cols-2 gap-2 text-xs">
            <div class="rounded-xl bg-indigo/10 px-3 py-2 text-indigo">
              {{ preferences.t('upload') }}：{{ formatTraffic(item.upload) }}
            </div>
            <div class="rounded-xl bg-cyan/10 px-3 py-2 text-cyan">
              {{ preferences.t('download') }}：{{ formatTraffic(item.download) }}
            </div>
          </div>
        </div>
      </div>

      <!-- 桌面端表格 -->
      <div class="hidden overflow-x-auto md:block">
        <table class="w-full text-left text-sm">
          <thead class="border-b border-border text-xs uppercase tracking-[0.18em] text-muted">
            <tr>
              <th class="pb-3">Date</th>
              <th class="pb-3">{{ preferences.t('upload') }}</th>
              <th class="pb-3">{{ preferences.t('download') }}</th>
              <th class="pb-3">Total</th>
              <th class="pb-3">Usage</th>
            </tr>
          </thead>

          <tbody>
            <tr
              v-for="item in dailyTraffic"
              :key="item.date"
              class="border-b border-border/60"
            >
              <td class="py-4 mono text-xs text-muted">
                {{ item.date }}
              </td>

              <td class="py-4 text-indigo">
                {{ formatTraffic(item.upload) }}
              </td>

              <td class="py-4 text-cyan">
                {{ formatTraffic(item.download) }}
              </td>

              <td class="py-4 mono">
                {{ formatTraffic(item.upload + item.download) }}
              </td>

              <td class="py-4">
                <div class="h-2 w-40 overflow-hidden rounded-full bg-elevated">
                  <div
                    class="h-full rounded-full bg-gradient-to-r from-indigo to-cyan"
                    :style="{ width: ((item.upload + item.download) / dailyMax * 100) + '%' }"
                  ></div>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>
</template>
