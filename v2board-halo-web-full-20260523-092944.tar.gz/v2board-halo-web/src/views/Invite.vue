<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import {
  fetchInviteApi,
  saveInviteApi,
  fetchCommissionApi,
  transferCommissionApi,
  removeInviteApi
} from '@/api/invite'
import { usePreferencesStore } from '@/stores/preferences'
import { useUserStore } from '@/stores/user'
import { formatDateTime, formatMoney } from '@/utils/format'
import { Copy, Check, Plus, Gift, Share2, RefreshCw, ArrowRightLeft, X } from 'lucide-vue-next'
import { useFeedbackStore } from '@/stores/feedback'

const preferences = usePreferencesStore()
const user = useUserStore()
const feedback = useFeedbackStore()

const invites = ref<any[]>([])
const commissions = ref<any[]>([])
const loading = ref(false)
const message = ref('')
const error = ref('')
const copied = ref('')
const showTransferConfirm = ref(false)
const transferAmount = ref<number | null>(null)

const inviteBase = computed(() => `${location.origin}/register?code=`)

function normalizeInviteList(data: any) {
  if (Array.isArray(data)) return data
  if (Array.isArray(data?.data)) return data.data
  if (Array.isArray(data?.codes)) return data.codes
  if (Array.isArray(data?.invite_codes)) return data.invite_codes
  if (Array.isArray(data?.invites)) return data.invites
  if (Array.isArray(data?.list)) return data.list
  return []
}

function normalizeCommissionList(data: any) {
  if (Array.isArray(data)) return data
  if (Array.isArray(data?.data)) return data.data
  if (Array.isArray(data?.records)) return data.records
  if (Array.isArray(data?.commission)) return data.commission
  if (Array.isArray(data?.list)) return data.list
  return []
}

function codeOf(item: any) {
  return item.code || item.invite_code || item.inviteCode || item.id || ''
}

function linkOf(item: any) {
  return inviteBase.value + codeOf(item)
}

function amountOf(item: any) {
  return item.amount || item.commission || item.commission_amount || item.get_amount || 0
}

function emailOf(item: any) {
  return item.email || item.user_email || item.invite_user_email || item.target_email || '-'
}

async function copyText(text: string, key: string) {
  if (!text) return

  await navigator.clipboard.writeText(text)
  copied.value = key

  setTimeout(() => {
    copied.value = ''
  }, 1400)
}

async function load(options: { keepMessage?: boolean } = {}) {
  loading.value = true

  if (!options.keepMessage) {
    message.value = ''
    error.value = ''
  }

  try {
    const [inviteRes, commissionRes] = await Promise.allSettled([
      fetchInviteApi(),
      fetchCommissionApi()
    ])

    if (inviteRes.status === 'fulfilled') {
      invites.value = normalizeInviteList(inviteRes.value.data)
    }

    if (commissionRes.status === 'fulfilled') {
      commissions.value = normalizeCommissionList(commissionRes.value.data)
    }

    await user.fetchUser()
  } catch (e: any) {
    error.value = e.message || (preferences.lang === 'zh' ? '加载失败' : 'Load failed')
  } finally {
    loading.value = false
  }
}

async function createInvite() {
  loading.value = true
  message.value = ''
  error.value = ''

  try {
    await saveInviteApi()
    await load({ keepMessage: true })
    feedback.success(preferences.lang === 'zh' ? '邀请码已创建' : 'Invite code created')
  } catch (e: any) {
    error.value = e.message || (preferences.lang === 'zh' ? '创建失败' : 'Create failed')
    feedback.error(error.value)
  } finally {
    loading.value = false
  }
}


function openTransferConfirm() {
  message.value = ''
  error.value = ''

  const balance = Number(user.info?.commission_balance || 0)
  transferAmount.value = balance > 0 ? Number((balance / 100).toFixed(2)) : null

  showTransferConfirm.value = true
}

async function confirmTransferCommission() {
  if (!transferAmount.value || transferAmount.value <= 0) {
    error.value = preferences.lang === 'zh' ? '请输入划转金额' : 'Please enter transfer amount'
    return
  }

  loading.value = true
  message.value = ''
  error.value = ''

  try {
    const cents = Math.round(Number(transferAmount.value) * 100)

    await transferCommissionApi({
      transfer_amount: cents,
      amount: cents
    })

    showTransferConfirm.value = false
    feedback.success(preferences.lang === 'zh'
      ? '佣金已成功划转到余额'
      : 'Commission transferred to balance')

    transferAmount.value = null
    await load({ keepMessage: true })
  } catch (e: any) {
    const msg = e.message || ''

    if (
      msg.includes('422') ||
      msg.includes('transfer_amount') ||
      msg.includes('amount')
    ) {
      error.value = preferences.lang === 'zh'
        ? '划转失败：请确认金额是否满足最低划转要求。'
        : 'Transfer failed: please check minimum transfer amount.'
    } else if (
      msg.includes('Network Error') ||
      msg.includes('404') ||
      msg.includes('Not Found')
    ) {
      error.value = preferences.lang === 'zh'
        ? '当前后端不支持佣金划转接口。'
        : 'Commission transfer API is not supported.'
    } else {
      error.value = msg || (preferences.lang === 'zh' ? '划转失败' : 'Transfer failed')
      feedback.error(error.value)
    }
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<template>
  <div class="space-y-4">
    <!-- 顶部 -->
    <section class="halo-card p-4 lg:p-6">
      <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div class="flex items-center gap-3">
          <div class="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo/15 text-indigo">
            <Gift :size="22" />
          </div>

          <div>
            <div class="text-[10px] uppercase tracking-[0.26em] text-muted">
              Invite
            </div>
            <h1 class="mt-1 text-xl font-semibold">
              {{ preferences.lang === 'zh' ? '邀请返利' : 'Invite Rewards' }}
            </h1>
          </div>
        </div>

        <div class="flex gap-2">
          <button class="halo-btn halo-btn-ghost" :disabled="loading" @click="load()">
            <RefreshCw :size="16" :class="loading ? 'animate-spin' : ''" />
          </button>

          <button class="halo-btn halo-btn-primary" :disabled="loading" @click="createInvite">
            <Plus :size="16" />
            {{ preferences.lang === 'zh' ? '创建邀请码' : 'Create Code' }}
          </button>
        </div>
      </div>

      <div
        v-if="message"
        class="mt-4 rounded-xl border border-lime/40 bg-lime/10 px-4 py-3 text-sm text-lime"
      >
        {{ message }}
      </div>

      <div
        v-if="error"
        class="mt-4 rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta"
      >
        {{ error }}
      </div>
    </section>

    <!-- 概览 -->
    <section class="grid gap-4 md:grid-cols-3">
      <div class="halo-card p-5">
        <div class="text-sm text-muted">
          {{ preferences.lang === 'zh' ? '佣金余额' : 'Commission Balance' }}
        </div>
        <div class="mono mt-4 text-3xl font-semibold text-lime">
          {{ formatMoney(user.info?.commission_balance) }}
        </div>
      </div>

      <div class="halo-card p-5">
        <div class="text-sm text-muted">
          {{ preferences.lang === 'zh' ? '邀请码数量' : 'Invite Codes' }}
        </div>
        <div class="mono mt-4 text-3xl font-semibold text-indigo">
          {{ invites.length }}
        </div>
      </div>

      <div class="halo-card p-5">
        <div class="text-sm text-muted">
          {{ preferences.lang === 'zh' ? '佣金操作' : 'Commission Action' }}
        </div>

        <button
          class="halo-btn halo-btn-primary mt-4 w-full"
          :disabled="loading"
          @click="openTransferConfirm"
        >
          <ArrowRightLeft :size="16" />
          {{ preferences.lang === 'zh' ? '划转到余额' : 'Transfer to Balance' }}
        </button>
      </div>
    </section>

    <!-- 邀请码 -->
    <section class="halo-card p-4 lg:p-6">
      <div class="mb-5 flex items-center gap-2">
        <Share2 :size="18" class="text-cyan" />
        <h2 class="font-semibold">
          {{ preferences.lang === 'zh' ? '邀请码和分享链接' : 'Invite Codes & Links' }}
        </h2>
      </div>

      <div class="space-y-3">
        <div
          v-for="item in invites"
          :key="codeOf(item)"
          class="rounded-2xl border border-border bg-canvas/45 p-4"
        >
          <div class="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div class="min-w-0">
              <div class="mb-1 text-xs text-muted">Code</div>

              <div class="mono text-sm text-indigo">
                {{ codeOf(item) }}
              </div>

              <div class="mt-2 break-all text-xs text-muted">
                {{ linkOf(item) }}
              </div>

              <div class="mt-2 flex flex-wrap gap-2 text-[11px] text-muted">
                <span v-if="item.created_at">
                  {{ preferences.lang === 'zh' ? '创建时间' : 'Created' }}:
                  {{ formatDateTime(item.created_at) }}
                </span>
                <span v-if="item.status !== undefined">
                  Status: {{ item.status }}
                </span>
              </div>
            </div>

            <div class="flex gap-2">
              <button
                class="halo-btn halo-btn-ghost text-xs"
                @click="copyText(String(codeOf(item)), 'code-' + codeOf(item))"
              >
                <Check v-if="copied === 'code-' + codeOf(item)" :size="14" />
                <Copy v-else :size="14" />
                {{ preferences.lang === 'zh' ? '复制码' : 'Code' }}
              </button>

              <button
                class="halo-btn halo-btn-primary text-xs"
                @click="copyText(linkOf(item), 'link-' + codeOf(item))"
              >
                <Check v-if="copied === 'link-' + codeOf(item)" :size="14" />
                <Copy v-else :size="14" />
                {{ preferences.lang === 'zh' ? '复制链接' : 'Link' }}
              </button>
            </div>
          </div>
        </div>

        <div
          v-if="!invites.length"
          class="rounded-2xl border border-border bg-canvas/45 p-6 text-center text-sm text-muted"
        >
          {{ preferences.lang === 'zh' ? '暂无邀请码，请点击创建' : 'No invite codes, please create one' }}
        </div>
      </div>
    </section>

    <!-- 邀请/佣金记录 -->
    <section class="halo-card overflow-hidden">
      <div class="border-b border-border p-4 lg:p-5">
        <h2 class="font-semibold">
          {{ preferences.lang === 'zh' ? '邀请 / 佣金记录' : 'Invite / Commission Records' }}
        </h2>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-left text-sm">
          <thead class="border-b border-border text-xs uppercase tracking-[0.18em] text-muted">
            <tr>
              <th class="p-4">ID</th>
              <th class="p-4">{{ preferences.lang === 'zh' ? '用户' : 'User' }}</th>
              <th class="p-4">{{ preferences.lang === 'zh' ? '金额' : 'Amount' }}</th>
              <th class="p-4">{{ preferences.lang === 'zh' ? '状态' : 'Status' }}</th>
              <th class="p-4">{{ preferences.lang === 'zh' ? '时间' : 'Time' }}</th>
            </tr>
          </thead>

          <tbody>
            <tr
              v-for="item in commissions"
              :key="item.id || item.trade_no || item.created_at"
              class="border-b border-border/60"
            >
              <td class="p-4 mono text-xs text-muted">
                {{ item.id || item.trade_no || '-' }}
              </td>

              <td class="p-4">
                {{ emailOf(item) }}
              </td>

              <td class="p-4 text-lime">
                {{ formatMoney(amountOf(item)) }}
              </td>

              <td class="p-4">
                {{ item.status ?? item.type ?? '-' }}
              </td>

              <td class="p-4 text-muted">
                {{ formatDateTime(item.created_at) }}
              </td>
            </tr>

            <tr v-if="!commissions.length">
              <td colspan="5" class="p-6 text-center text-muted">
                {{ preferences.lang === 'zh' ? '暂无记录' : 'No records' }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <!-- 页面内确认弹窗 -->
    <Teleport to="body">
      <Transition
        enter-active-class="transition-opacity duration-150"
        leave-active-class="transition-opacity duration-150"
        enter-from-class="opacity-0"
        leave-to-class="opacity-0"
      >
        <div
          v-if="showTransferConfirm"
          class="fixed inset-0 z-[140] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
        >
          <div class="halo-card w-full max-w-md p-5">
            <div class="flex items-center justify-between">
              <div>
                <div class="text-[10px] uppercase tracking-[0.24em] text-muted">
                  Confirm
                </div>
                <h3 class="mt-1 text-lg font-semibold">
                  {{ preferences.lang === 'zh' ? '确认划转佣金？' : 'Transfer commission?' }}
                </h3>
              </div>

              <button class="rounded-lg p-2 hover:bg-white/5" @click="showTransferConfirm = false">
                <X :size="18" />
              </button>
            </div>

            <p class="mt-4 text-sm leading-7 text-muted">
              {{
                preferences.lang === 'zh'
                  ? '佣金划转后会进入账户余额，可用于购买套餐或续费。'
                  : 'After transfer, commission will be added to your balance.'
              }}
            </p>

            <div class="mt-4">
              <label class="mb-2 block text-xs text-muted">
                {{ preferences.lang === 'zh' ? '划转金额' : 'Transfer Amount' }}
              </label>
              <input
                v-model.number="transferAmount"
                class="halo-input"
                type="number"
                min="0.01"
                step="0.01"
                :placeholder="preferences.lang === 'zh' ? '请输入划转金额' : 'Enter amount'"
              />
              <div class="mt-2 text-xs text-muted">
                {{ preferences.lang === 'zh' ? '当前佣金余额：' : 'Commission balance: ' }}
                <span class="mono text-lime">{{ formatMoney(user.info?.commission_balance) }}</span>
              </div>
            </div>

            <div class="mt-5 flex gap-2">
              <button class="halo-btn halo-btn-ghost flex-1" @click="showTransferConfirm = false">
                {{ preferences.lang === 'zh' ? '取消' : 'Cancel' }}
              </button>

              <button class="halo-btn halo-btn-primary flex-1" :disabled="loading" @click="confirmTransferCommission">
                {{ loading ? preferences.t('loading') + '...' : preferences.lang === 'zh' ? '确认划转' : 'Confirm' }}
              </button>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>
