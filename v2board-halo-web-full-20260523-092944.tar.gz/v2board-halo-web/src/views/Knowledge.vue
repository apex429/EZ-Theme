<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { fetchKnowledgeApi } from '@/api/knowledge'

const list = ref<any[]>([])
const error = ref('')

async function load() {
  try {
    const res = await fetchKnowledgeApi()
    list.value = Array.isArray(res.data) ? res.data : (res.data?.data || [])
  } catch (e: any) {
    error.value = e.message || '知识库加载失败'
  }
}

onMounted(load)
</script>

<template>
  <div class="space-y-4">
    <section class="halo-card p-6">
      <div class="text-xs uppercase tracking-[0.26em] text-muted">Knowledge</div>
      <h1 class="mt-2 text-2xl font-semibold">知识库</h1>
    </section>

    <div v-if="error" class="rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta">{{ error }}</div>

    <section class="grid gap-4 md:grid-cols-2">
      <article v-for="item in list" :key="item.id" class="halo-card p-5">
        <h2 class="text-lg font-semibold">{{ item.title || item.name }}</h2>
        <div class="mt-3 text-sm leading-7 text-muted" v-html="item.body || item.content || item.description"></div>
      </article>
      <div v-if="!list.length" class="halo-card p-6 text-muted">暂无知识库内容</div>
    </section>
  </div>
</template>
