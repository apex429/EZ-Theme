<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useUserStore } from '@/stores/user'
import { formatMoney } from '@/utils/format'
import { getPaymentMethodApi, saveOrderApi, checkoutOrderApi } from '@/api/order'
import { usePreferencesStore } from '@/stores/preferences'
import { CreditCard, WalletCards } from 'lucide-vue-next'

const user = useUserStore()
const preferences = usePreferencesStore()

const amount = ref<number | null>(null)
const paymentId = ref<any>('')
const paymentMethods = ref<any[]>([])
const loading = ref(false)
const message = ref('')
const payUrl = ref('')

function normalizePayment(data: any) {
  if (Array.isArray(data)) return data
  if (Array.isArray(data?.data)) return data.data
  if (Array.isArray(data?.methods)) return data.methods
  return []
}

async function loadPayments() {
  try {
    const res = await getPaymentMethodApi()
    paymentMethods.value = normalizePayment(res.data)
    if (paymentMethods.value.length) {
      paymentId.value = paymentMethods.value[0].id
    }
  } catch (e: any) {
    message.value = e.message || (preferences.lang === 'zh' ? '支付方式加载失败' : 'Payment methods failed')
  }
}

async function recharge() {
  if (!amount.value || amount.value <= 0) {
    message.value = preferences.lang === 'zh' ? '请输入充值金额' : 'Please enter amount'
    return
  }

  if (!paymentId.value) {
    message.value = preferences.lang === 'zh' ? '请选择支付方式' : 'Please select payment'
    return
  }

  loading.value = true
  message.value = ''
  payUrl.value = ''

  try {
    // 创建余额充值订单，部分 V2Board 版本可能字段不同
    const orderRes = await saveOrderApi({
      period: 'balance',
      recharge_amount: Math.round(amount.value * 100),
      amount: Math.round(amount.value * 100)
    })

    const tradeNo =
      orderRes.data?.trade_no ||
      orderRes.data?.tradeNo ||
      orderRes.data

    if (!tradeNo) {
      throw new Error(preferences.lang === 'zh' ? '订单创建失败，未返回订单号' : 'No trade number returned')
    }

    const checkoutRes = await checkoutOrderApi({
      trade_no: tradeNo,
      method: paymentId.value
    })

    const url =
      checkoutRes.data?.url ||
      checkoutRes.data?.pay_url ||
      checkoutRes.data?.payment_url ||
      checkoutRes.data

    if (typeof url === 'string' && url.startsWith('http')) {
      payUrl.value = url
      window.open(url, '_blank')
    } else {
      message.value = preferences.lang === 'zh'
        ? '订单已创建，请到订单页面继续支付'
        : 'Order created, please continue in orders'
    }

    await user.fetchUser()
  } catch (e: any) {
    message.value = e.message || (preferences.lang === 'zh' ? '充值失败' : 'Recharge failed')
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  user.fetchUser()
  loadPayments()
})
</script>

<template>
  <div class="space-y-4">
    <section class="halo-card p-4 lg:p-6">
      <div class="flex items-center gap-3">
        <div class="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo/15 text-indigo">
          <WalletCards :size="22" />
        </div>
        <div>
          <div class="text-[10px] uppercase tracking-[0.26em] text-muted">Wallet</div>
          <h1 class="mt-1 text-xl font-semibold">
            {{ preferences.lang === 'zh' ? '钱包佣金' : 'Wallet' }}
          </h1>
        </div>
      </div>
    </section>

    <section class="grid gap-4 md:grid-cols-2">
      <div class="halo-card p-5 lg:p-6">
        <div class="text-sm text-muted">
          {{ preferences.lang === 'zh' ? '账户余额' : 'Balance' }}
        </div>
        <div class="mono mt-4 text-4xl font-semibold text-indigo">
          {{ formatMoney(user.info?.balance) }}
        </div>
      </div>

      <div class="halo-card p-5 lg:p-6">
        <div class="text-sm text-muted">
          {{ preferences.lang === 'zh' ? '佣金余额' : 'Commission' }}
        </div>
        <div class="mono mt-4 text-4xl font-semibold text-lime">
          {{ formatMoney(user.info?.commission_balance) }}
        </div>
      </div>
    </section>

    <section class="halo-card p-4 lg:p-6">
      <div class="mb-5 flex items-center gap-3">
        <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan/10 text-cyan">
          <CreditCard :size="20" />
        </div>
        <div>
          <h2 class="font-semibold">
            {{ preferences.lang === 'zh' ? '余额充值' : 'Recharge' }}
          </h2>
          <p class="mt-1 text-xs text-muted">
            {{ preferences.lang === 'zh' ? '选择支付方式并输入充值金额' : 'Choose payment method and enter amount' }}
          </p>
        </div>
      </div>

      <div class="grid gap-3 md:grid-cols-[1fr_1fr_auto]">
        <input
          v-model.number="amount"
          class="halo-input"
          type="number"
          min="1"
          :placeholder="preferences.lang === 'zh' ? '充值金额，例如 50' : 'Amount, e.g. 50'"
        />

        <select v-model="paymentId" class="halo-input">
          <option value="">
            {{ preferences.lang === 'zh' ? '选择支付方式' : 'Select payment' }}
          </option>
          <option
            v-for="item in paymentMethods"
            :key="item.id"
            :value="item.id"
          >
            {{ item.name || item.payment || item.type || ('Payment #' + item.id) }}
          </option>
        </select>

        <button class="halo-btn halo-btn-primary" :disabled="loading" @click="recharge">
          {{ loading ? preferences.t('loading') + '...' : preferences.lang === 'zh' ? '立即充值' : 'Recharge' }}
        </button>
      </div>

      <div
        v-if="message"
        class="mt-4 rounded-xl border border-indigo/40 bg-indigo/10 px-4 py-3 text-sm text-indigo"
      >
        {{ message }}
      </div>

      <a
        v-if="payUrl"
        :href="payUrl"
        target="_blank"
        class="halo-btn halo-btn-ghost mt-4"
      >
        {{ preferences.lang === 'zh' ? '打开支付链接' : 'Open payment link' }}
      </a>
    </section>
  </div>
</template>
