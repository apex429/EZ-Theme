<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { fetchOrdersApi } from '@/api/order'
import { formatDateTime, formatMoney } from '@/utils/format'

const orders = ref<any[]>([])
const error = ref('')

async function load() {
  try {
    const res = await fetchOrdersApi()
    orders.value = Array.isArray(res.data) ? res.data : (res.data?.data || [])
  } catch (e: any) {
    error.value = e.message || '订单加载失败'
  }
}

onMounted(load)
</script>

<template>
  <div class="space-y-4">
    <section class="halo-card p-6">
      <div class="text-xs uppercase tracking-[0.26em] text-muted">Orders</div>
      <h1 class="mt-2 text-2xl font-semibold">订单记录</h1>
    </section>

    <div v-if="error" class="rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta">{{ error }}</div>

    <section class="halo-card overflow-hidden">
      <div class="overflow-x-auto">
        <table class="w-full text-left text-sm">
          <thead class="border-b border-border text-muted">
            <tr>
              <th class="p-4">订单号</th>
              <th class="p-4">金额</th>
              <th class="p-4">状态</th>
              <th class="p-4">时间</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="item in orders" :key="item.trade_no || item.id" class="border-b border-border/70">
              <td class="mono p-4">{{ item.trade_no || item.id }}</td>
              <td class="p-4">{{ formatMoney(item.total_amount || item.amount) }}</td>
              <td class="p-4">{{ item.status }}</td>
              <td class="p-4">{{ formatDateTime(item.created_at) }}</td>
            </tr>
            <tr v-if="!orders.length">
              <td class="p-6 text-muted" colspan="4">暂无订单</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>
</template>
