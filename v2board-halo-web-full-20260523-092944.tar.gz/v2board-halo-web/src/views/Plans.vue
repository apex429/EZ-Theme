<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { fetchPlansApi, type Plan } from '@/api/plan'
import PlanCard from '@/components/PlanCard.vue'
import { LayoutGrid, List, LayoutList } from 'lucide-vue-next'

const plans = ref<Plan[]>([])
const loading = ref(false)
const error = ref('')
const layout = ref<'card' | 'list' | 'compact'>('card')

async function load() {
  loading.value = true
  error.value = ''
  try {
    const res = await fetchPlansApi()
    plans.value = Array.isArray(res.data) ? res.data : []
  } catch (e: any) {
    error.value = e.message || '套餐加载失败'
  } finally {
    loading.value = false
  }
}

function selectPlan(plan: Plan) {
  console.log('选择套餐:', plan)
  // TODO: 跳转到订单页面
}

onMounted(load)
</script>

<template>
  <div class="space-y-3 lg:space-y-4">
    <section class="halo-card p-4 lg:p-6">
      <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div class="text-[10px] uppercase tracking-[0.26em] text-muted">Plans</div>
          <h1 class="mt-1 text-lg font-semibold lg:text-2xl">购买套餐</h1>
          <p class="mt-2 text-xs text-muted sm:text-sm">选择适合你的套餐周期</p>
        </div>

        <div class="flex gap-1 rounded-xl border border-border bg-elevated/50 p-1">
          <button
            class="rounded-lg px-3 py-2 text-xs transition"
            :class="layout === 'card' ? 'bg-indigo text-white' : 'text-muted hover:text-onSurface'"
            @click="layout = 'card'"
          >
            <LayoutGrid :size="16" />
          </button>
          <button
            class="rounded-lg px-3 py-2 text-xs transition"
            :class="layout === 'list' ? 'bg-indigo text-white' : 'text-muted hover:text-onSurface'"
            @click="layout = 'list'"
          >
            <List :size="16" />
          </button>
          <button
            class="rounded-lg px-3 py-2 text-xs transition"
            :class="layout === 'compact' ? 'bg-indigo text-white' : 'text-muted hover:text-onSurface'"
            @click="layout = 'compact'"
          >
            <LayoutList :size="16" />
          </button>
        </div>
      </div>
    </section>

    <div v-if="error" class="rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta">
      {{ error }}
    </div>

    <section 
      class="grid gap-3 lg:gap-4"
      :class="{
        'md:grid-cols-2 xl:grid-cols-3': layout === 'card',
        'grid-cols-1': layout === 'list',
        'sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4': layout === 'compact'
      }"
    >
      <PlanCard
        v-for="plan in plans"
        :key="plan.id"
        :plan="plan"
        :layout="layout"
        @select="selectPlan"
      />

      <div v-if="!loading && !plans.length" class="halo-card p-6 text-center text-muted">
        暂无可购买套餐
      </div>
    </section>
  </div>
</template>
