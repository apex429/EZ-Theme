<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { fetchServersApi } from '@/api/server'

const list = ref<any[]>([])
const error = ref('')

async function load() {
  try {
    const res = await fetchServersApi()
    list.value = Array.isArray(res.data) ? res.data : []
  } catch (e: any) {
    error.value = e.message || '节点加载失败'
  }
}

onMounted(load)
</script>

<template>
  <div class="space-y-4">
    <section class="halo-card p-6">
      <div class="text-xs uppercase tracking-[0.26em] text-muted">Servers</div>
      <h1 class="mt-2 text-2xl font-semibold">节点列表</h1>
    </section>

    <div v-if="error" class="rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta">{{ error }}</div>

    <section class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      <div v-for="item in list" :key="item.id || item.name" class="halo-card p-5">
        <div class="text-lg font-semibold">{{ item.name || item.host || 'Unnamed Server' }}</div>
        <div class="mt-3 text-sm text-muted">倍率：{{ item.rate || item.ratio || '-' }}</div>
        <div class="mt-1 text-sm text-muted">类型：{{ item.type || item.network || '-' }}</div>
      </div>
      <div v-if="!list.length" class="halo-card p-6 text-muted">暂无节点或当前套餐不可见</div>
    </section>
  </div>
</template>
