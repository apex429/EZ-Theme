<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import {
  Copy,
  Check,
  RefreshCw,
  ShieldCheck,
  Users,
  Send,
  BookOpen,
  Activity,
  LogOut,
  Mail,
  KeyRound,
  CalendarDays,
  Clock,
  Headphones,
  Palette,
  Languages
} from 'lucide-vue-next'
import { useUserStore } from '@/stores/user'
import { useAuthStore } from '@/stores/auth'
import { usePreferencesStore } from '@/stores/preferences'
import { resetSecurityApi } from '@/api/user'
import { formatDateTime } from '@/utils/format'
import { siteConfig } from '@/config/site'
import ThemeLangToggle from '@/components/ThemeLangToggle.vue'
import { useFeedbackStore } from '@/stores/feedback'

const router = useRouter()
const user = useUserStore()
const auth = useAuthStore()
const preferences = usePreferencesStore()
const feedback = useFeedbackStore()

const loading = ref(false)
const message = ref('')
const copiedKey = ref('')

const uuid = computed(() => user.info?.uuid || user.subscribe?.uuid || '-')
const email = computed(() => user.info?.email || '-')
const subscribeToken = computed(() => user.subscribe?.token || '-')
const isBanned = computed(() => Number(user.info?.banned || 0) === 1)

async function copyText(text: string, key: string) {
  if (!text || text === '-') return

  await navigator.clipboard.writeText(text)
  copiedKey.value = key

  setTimeout(() => {
    copiedKey.value = ''
  }, 1400)
}

async function resetSubscribe() {
  const ok = await feedback.confirm({
    title: preferences.lang === 'zh' ? '重置订阅链接' : 'Reset Subscription',
    message: preferences.lang === 'zh'
      ? '确定要重置订阅链接吗？旧订阅链接会立即失效。'
      : 'Reset subscription URL? Old URL will become invalid.',
    confirmText: preferences.lang === 'zh' ? '确认重置' : 'Reset',
    cancelText: preferences.lang === 'zh' ? '取消' : 'Cancel'
  })

  if (!ok) return

  loading.value = true
  message.value = ''

  try {
    await resetSecurityApi()
    await user.fetchUser()

    message.value = preferences.lang === 'zh'
      ? '订阅链接已重置，请重新复制或导入客户端。'
      : 'Subscription URL has been reset.'
    feedback.success(message.value)
  } catch (e: any) {
    message.value = e.message || (preferences.lang === 'zh' ? '重置失败' : 'Reset failed')
  } finally {
    loading.value = false
  }
}

function openUrl(url?: string) {
  if (!url) return
  window.open(url, '_blank')
}

function openSupport() {
  const support = siteConfig.support

  if (support.type === 'telegram' && support.telegram) {
    window.open(support.telegram, '_blank')
    return
  }

  if (support.link) {
    window.open(support.link, '_blank')
  }
}

function logout() {
  auth.logout()
  router.push('/login')
}

onMounted(() => {
  user.fetchUser()
})
</script>

<template>
  <div class="space-y-4">
    <!-- 顶部账户卡片 -->
    <section class="halo-card p-4 lg:p-6">
      <div class="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div class="flex items-center gap-4">
          <div class="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo to-cyan text-lg font-bold shadow-glow">
            {{ email.slice(0, 1).toUpperCase() }}
          </div>

          <div class="min-w-0">
            <div class="text-[10px] uppercase tracking-[0.26em] text-muted">
              Account Center
            </div>
            <h1 class="mt-1 truncate text-xl font-semibold lg:text-2xl">
              {{ preferences.lang === 'zh' ? '个人中心' : 'Account Center' }}
            </h1>
            <p class="mt-1 truncate text-sm text-muted">
              {{ email }}
            </p>
          </div>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <ThemeLangToggle />

          <button class="halo-btn halo-btn-ghost text-sm" @click="logout">
            <LogOut :size="16" />
            {{ preferences.t('logoutFull') }}
          </button>
        </div>
      </div>
    </section>

    <!-- 消息提示 -->
    <div
      v-if="message"
      class="rounded-xl border border-indigo/40 bg-indigo/10 px-4 py-3 text-sm text-indigo"
    >
      {{ message }}
    </div>

    <!-- 账户状态 -->
    <section class="grid gap-4 lg:grid-cols-3">
      <div class="halo-card p-5">
        <div class="flex items-center justify-between">
          <div>
            <div class="text-sm text-muted">
              {{ preferences.lang === 'zh' ? '账户状态' : 'Account Status' }}
            </div>
            <div
              class="mt-3 inline-flex rounded-full px-3 py-1 text-sm"
              :class="isBanned ? 'bg-magenta/10 text-magenta' : 'bg-lime/10 text-lime'"
            >
              {{ isBanned ? (preferences.lang === 'zh' ? '已禁用' : 'Banned') : (preferences.lang === 'zh' ? '正常' : 'Active') }}
            </div>
          </div>

          <ShieldCheck :size="28" :class="isBanned ? 'text-magenta' : 'text-lime'" />
        </div>
      </div>

      <div class="halo-card p-5">
        <div class="flex items-center justify-between">
          <div>
            <div class="text-sm text-muted">
              {{ preferences.lang === 'zh' ? '注册时间' : 'Created At' }}
            </div>
            <div class="mono mt-3 text-sm">
              {{ formatDateTime(user.info?.created_at) }}
            </div>
          </div>

          <CalendarDays :size="28" class="text-indigo" />
        </div>
      </div>

      <div class="halo-card p-5">
        <div class="flex items-center justify-between">
          <div>
            <div class="text-sm text-muted">
              {{ preferences.lang === 'zh' ? '最近登录' : 'Last Login' }}
            </div>
            <div class="mono mt-3 text-sm">
              {{ formatDateTime(user.info?.last_login_at) }}
            </div>
          </div>

          <Clock :size="28" class="text-cyan" />
        </div>
      </div>
    </section>

    <!-- 账户信息和订阅安全 -->
    <section class="grid gap-4 xl:grid-cols-[1fr_1fr]">
      <div class="halo-card p-4 lg:p-6">
        <div class="mb-5 flex items-center gap-3">
          <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo/10 text-indigo">
            <Mail :size="20" />
          </div>

          <div>
            <h2 class="font-semibold">
              {{ preferences.lang === 'zh' ? '账户信息' : 'Account Info' }}
            </h2>
            <p class="mt-1 text-xs text-muted">
              {{ preferences.lang === 'zh' ? '查看并复制你的账户标识' : 'View and copy account identifiers' }}
            </p>
          </div>
        </div>

        <div class="space-y-3">
          <div class="rounded-2xl border border-border bg-canvas/45 p-3">
            <div class="mb-2 text-xs text-muted">
              {{ preferences.t('email') }}
            </div>

            <div class="flex items-center justify-between gap-3">
              <div class="truncate text-sm">
                {{ email }}
              </div>

              <button class="halo-btn halo-btn-ghost h-9 px-3 text-xs" @click="copyText(email, 'email')">
                <Check v-if="copiedKey === 'email'" :size="14" />
                <Copy v-else :size="14" />
              </button>
            </div>
          </div>

          <div class="rounded-2xl border border-border bg-canvas/45 p-3">
            <div class="mb-2 text-xs text-muted">
              UUID
            </div>

            <div class="flex items-center justify-between gap-3">
              <div class="mono truncate text-xs">
                {{ uuid }}
              </div>

              <button class="halo-btn halo-btn-ghost h-9 px-3 text-xs" @click="copyText(uuid, 'uuid')">
                <Check v-if="copiedKey === 'uuid'" :size="14" />
                <Copy v-else :size="14" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="halo-card p-4 lg:p-6">
        <div class="mb-5 flex items-center gap-3">
          <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan/10 text-cyan">
            <KeyRound :size="20" />
          </div>

          <div>
            <h2 class="font-semibold">
              {{ preferences.lang === 'zh' ? '订阅安全' : 'Subscription Security' }}
            </h2>
            <p class="mt-1 text-xs text-muted">
              {{ preferences.lang === 'zh' ? '重置订阅链接可让旧链接失效' : 'Reset subscription URL to invalidate old links' }}
            </p>
          </div>
        </div>

        <div class="rounded-2xl border border-border bg-canvas/45 p-3">
          <div class="mb-2 text-xs text-muted">
            Subscribe Token
          </div>

          <div class="flex items-center justify-between gap-3">
            <div class="mono truncate text-xs">
              {{ subscribeToken }}
            </div>

            <button class="halo-btn halo-btn-ghost h-9 px-3 text-xs" @click="copyText(subscribeToken, 'token')">
              <Check v-if="copiedKey === 'token'" :size="14" />
              <Copy v-else :size="14" />
            </button>
          </div>
        </div>

        <button
          class="halo-btn halo-btn-primary mt-4 w-full"
          :disabled="loading"
          @click="resetSubscribe"
        >
          <RefreshCw :size="16" :class="loading ? 'animate-spin' : ''" />
          {{ loading ? preferences.t('loading') + '...' : preferences.lang === 'zh' ? '重置订阅链接' : 'Reset Subscription URL' }}
        </button>
      </div>
    </section>

    <!-- 社群和支持 -->
    <section class="grid gap-4 xl:grid-cols-3">
      <div class="halo-card p-5">
        <div class="mb-4 flex items-center gap-3">
          <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo/10 text-indigo">
            <Users :size="20" />
          </div>

          <div>
            <h2 class="font-semibold">
              {{ preferences.lang === 'zh' ? '官方群组' : 'Official Group' }}
            </h2>
            <p class="mt-1 text-xs text-muted">
              {{ preferences.lang === 'zh' ? '加入用户交流社区' : 'Join our community' }}
            </p>
          </div>
        </div>

        <button
          class="halo-btn halo-btn-ghost w-full"
          @click="openUrl(siteConfig.community?.telegramGroup)"
        >
          <Send :size="16" />
          {{ preferences.lang === 'zh' ? '加入官方群' : 'Join Group' }}
        </button>
      </div>

      <div class="halo-card p-5">
        <div class="mb-4 flex items-center gap-3">
          <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan/10 text-cyan">
            <BookOpen :size="20" />
          </div>

          <div>
            <h2 class="font-semibold">
              {{ preferences.lang === 'zh' ? '使用文档' : 'Documentation' }}
            </h2>
            <p class="mt-1 text-xs text-muted">
              {{ preferences.lang === 'zh' ? '查看教程和客户端配置' : 'Guides and client setup' }}
            </p>
          </div>
        </div>

        <button
          class="halo-btn halo-btn-ghost w-full"
          @click="openUrl(siteConfig.community?.docsUrl)"
        >
          <BookOpen :size="16" />
          {{ preferences.lang === 'zh' ? '查看文档' : 'View Docs' }}
        </button>
      </div>

      <div class="halo-card p-5">
        <div class="mb-4 flex items-center gap-3">
          <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-lime/10 text-lime">
            <Headphones :size="20" />
          </div>

          <div>
            <h2 class="font-semibold">
              {{ preferences.lang === 'zh' ? '联系客服' : 'Support' }}
            </h2>
            <p class="mt-1 text-xs text-muted">
              {{ preferences.lang === 'zh' ? '遇到问题可以联系支持' : 'Contact us for help' }}
            </p>
          </div>
        </div>

        <button class="halo-btn halo-btn-primary w-full" @click="openSupport">
          <Headphones :size="16" />
          {{ siteConfig.support.buttonText }}
        </button>
      </div>
    </section>

    <!-- 偏好设置说明 -->
    <section class="halo-card p-4 lg:p-6">
      <div class="mb-5 flex items-center gap-3">
        <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-amber/10 text-amber">
          <Palette :size="20" />
        </div>

        <div>
          <h2 class="font-semibold">
            {{ preferences.lang === 'zh' ? '偏好设置' : 'Preferences' }}
          </h2>
          <p class="mt-1 text-xs text-muted">
            {{ preferences.lang === 'zh' ? '主题和语言会自动保存到当前浏览器' : 'Theme and language are saved in this browser' }}
          </p>
        </div>
      </div>

      <div class="flex flex-wrap items-center gap-3">
        <ThemeLangToggle />

        <div class="flex items-center gap-2 rounded-xl border border-border bg-canvas/45 px-3 py-2 text-xs text-muted">
          <Languages :size="15" />
          {{ preferences.lang === 'zh' ? '当前语言：中文' : 'Current language: English' }}
        </div>

        <div class="flex items-center gap-2 rounded-xl border border-border bg-canvas/45 px-3 py-2 text-xs text-muted">
          <Activity :size="15" />
          {{ preferences.lang === 'zh' ? '当前主题：' : 'Current theme: ' }}{{ preferences.currentTheme.name }}
        </div>
      </div>
    </section>

    <!-- 安全提醒 -->
    <section class="rounded-2xl border border-amber/30 bg-amber/10 p-4 text-sm text-amber">
      <div class="font-medium">
        {{ preferences.lang === 'zh' ? '安全提醒' : 'Security Notice' }}
      </div>
      <div class="mt-2 leading-7">
        {{ preferences.lang === 'zh'
          ? '请勿将订阅链接公开分享。如果怀疑订阅链接泄露，请立即重置订阅链接。'
          : 'Do not share your subscription URL publicly. Reset it immediately if you suspect it has been leaked.'
        }}
      </div>
    </section>
  </div>
</template>
