<script setup lang="ts">
import { ref } from 'vue'
import { RouterLink } from 'vue-router'
import { forgotApi } from '@/api/auth'

const email = ref('')
const message = ref('')
const error = ref('')
const loading = ref(false)

async function submit() {
  error.value = ''
  message.value = ''
  loading.value = true
  try {
    await forgotApi({ email: email.value })
    message.value = '如果该邮箱存在，系统会发送重置邮件'
  } catch (e: any) {
    error.value = e.message || '提交失败'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="flex min-h-screen items-center justify-center px-4 py-10">
    <section class="halo-card w-full max-w-md p-6">
      <div class="mb-6">
        <div class="text-xs uppercase tracking-[0.26em] text-muted">Reset Password</div>
        <h1 class="mt-2 text-2xl font-semibold">忘记密码</h1>
      </div>

      <form class="space-y-4" @submit.prevent="submit">
        <input v-model="email" class="halo-input" type="email" placeholder="邮箱" required />
        <div v-if="error" class="rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta">{{ error }}</div>
        <div v-if="message" class="rounded-xl border border-lime/40 bg-lime/10 px-4 py-3 text-sm text-lime">{{ message }}</div>
        <button class="halo-btn halo-btn-primary w-full" :disabled="loading">{{ loading ? '提交中...' : '提交' }}</button>
      </form>

      <RouterLink class="mt-5 block text-sm text-muted hover:text-onSurface" to="/login">返回登录</RouterLink>
    </section>
  </div>
</template>
