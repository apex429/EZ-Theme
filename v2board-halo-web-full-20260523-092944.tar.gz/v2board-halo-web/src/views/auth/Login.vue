<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRouter, RouterLink } from 'vue-router'
import { ArrowRight, Headphones } from 'lucide-vue-next'
import { useAuthStore } from '@/stores/auth'
import { siteConfig } from '@/config/site'
import ThemeLangToggle from '@/components/ThemeLangToggle.vue'
import { usePreferencesStore } from '@/stores/preferences'

const router = useRouter()
const auth = useAuthStore()
const preferences = usePreferencesStore()

const email = ref('')
const password = ref('')
const loading = ref(false)
const error = ref('')

const bgStyle = computed(() => ({
  backgroundImage: `linear-gradient(${siteConfig.login.backgroundMask}, ${siteConfig.login.backgroundMask}), url(${siteConfig.login.backgroundImage})`,
  backgroundSize: 'cover',
  backgroundPosition: 'center'
}))

async function submit() {
  error.value = ''
  loading.value = true

  try {
    await auth.login(email.value, password.value)
    router.push('/dashboard')
  } catch (e: any) {
    error.value = e.message || '登录失败'
  } finally {
    loading.value = false
  }
}

function openSupport() {
  const support = siteConfig.support
  if (!support.enabled) return

  if (support.type === 'telegram' && support.telegram) {
    window.open(support.telegram, '_blank')
    return
  }

  if (support.type === 'link' && support.link) {
    window.open(support.link, '_blank')
  }
}
</script>

<template>
  <div class="min-h-screen px-4 py-6 md:px-6 md:py-10">
    <div class="fixed right-4 top-4 z-50"><ThemeLangToggle /></div>
    <div class="mx-auto grid min-h-[calc(100vh-48px)] max-w-7xl overflow-hidden rounded-[28px] border border-border bg-surface/60 shadow-halo lg:grid-cols-2">
      <section
        class="relative hidden min-h-[720px] overflow-hidden lg:block"
        :style="bgStyle"
      >
        <div class="absolute inset-0 bg-gradient-to-br from-black/20 via-transparent to-black/40"></div>

        <div class="relative z-10 flex h-full flex-col justify-between p-10 xl:p-14">
          <div>
            <div class="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-2 text-xs uppercase tracking-[0.2em] text-white/70 backdrop-blur">
              <span class="h-2 w-2 rounded-full bg-[var(--indigo)] pulse"></span>
              {{ siteConfig.siteName }}
            </div>

            <h1 class="mt-8 text-5xl font-bold leading-tight text-white xl:text-7xl">
              {{ siteConfig.login.title }}
              <span class="block text-[var(--indigo)]">{{ siteConfig.login.highlight }}</span>
              {{ siteConfig.login.subtitle }}
            </h1>

            <p class="mt-6 max-w-xl text-lg leading-8 text-white/75">
              {{ siteConfig.login.description }}
            </p>
          </div>

          <div class="grid grid-cols-3 gap-4">
            <div class="rounded-2xl border border-white/10 bg-black/20 p-4 backdrop-blur">
              <div class="text-2xl font-semibold text-white">50+</div>
              <div class="mt-1 text-sm text-white/60">全球节点</div>
            </div>
            <div class="rounded-2xl border border-white/10 bg-black/20 p-4 backdrop-blur">
              <div class="text-2xl font-semibold text-white">99.9%</div>
              <div class="mt-1 text-sm text-white/60">在线率</div>
            </div>
            <div class="rounded-2xl border border-white/10 bg-black/20 p-4 backdrop-blur">
              <div class="text-2xl font-semibold text-white">24/7</div>
              <div class="mt-1 text-sm text-white/60">支持</div>
            </div>
          </div>
        </div>
      </section>

      <section class="flex items-center justify-center bg-canvas/80 p-4 sm:p-6 lg:p-10">
        <div class="w-full max-w-md">
          <div class="halo-card p-6 sm:p-7">
            <div class="mb-6">
              <div class="text-xs uppercase tracking-[0.26em] text-muted">Sign in</div>
              <h2 class="mt-2 text-2xl font-semibold">{{ preferences.t('loginAccount') }}</h2>
              <p class="mt-2 text-sm text-muted">欢迎回到 {{ siteConfig.siteName }}</p>
            </div>

            <form class="space-y-4" @submit.prevent="submit">
              <input v-model="email" class="halo-input" type="email" :placeholder="preferences.t('email')" required />
              <input v-model="password" class="halo-input" type="password" :placeholder="preferences.t('password')" required />

              <div v-if="error" class="rounded-xl border border-magenta/40 bg-magenta/10 px-4 py-3 text-sm text-magenta">
                {{ error }}
              </div>

              <button class="halo-btn halo-btn-primary w-full" :disabled="loading">
                {{ loading ? preferences.t('loading') + '...' : preferences.t('login') }}
                <ArrowRight :size="16" />
              </button>
            </form>

            <div class="mt-5 flex justify-between text-sm text-muted">
              <RouterLink class="hover:text-onSurface" to="/register">{{ preferences.t('register') }}</RouterLink>
              <RouterLink class="hover:text-onSurface" to="/forgot">{{ preferences.t('forgotPassword') }}</RouterLink>
            </div>

            <button
              v-if="siteConfig.support.enabled && siteConfig.support.type !== 'qr'"
              class="halo-btn halo-btn-ghost mt-4 w-full"
              @click="openSupport"
            >
              <Headphones :size="16" />
              {{ siteConfig.support.buttonText }}
            </button>

            <div
              v-if="siteConfig.support.enabled && siteConfig.support.type === 'qr' && siteConfig.support.qrImage"
              class="mt-4 rounded-2xl border border-border bg-elevated/50 p-4 text-center"
            >
              <div class="mb-3 text-sm text-muted">{{ siteConfig.support.title }}</div>
              <img :src="siteConfig.support.qrImage" alt="support qr" class="mx-auto max-h-44 rounded-xl" />
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>
