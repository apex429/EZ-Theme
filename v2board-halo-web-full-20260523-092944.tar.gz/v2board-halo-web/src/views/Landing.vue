<script setup lang="ts">
import { useRouter } from 'vue-router'
import { ArrowRight, Zap, Shield, Globe, TrendingUp } from 'lucide-vue-next'

const router = useRouter()

const features = [
  {
    icon: Zap,
    title: '极速连接',
    desc: '全球节点，智能路由，毫秒级响应'
  },
  {
    icon: Shield,
    title: '安全加密',
    desc: '军事级加密，保护您的隐私安全'
  },
  {
    icon: Globe,
    title: '全球覆盖',
    desc: '50+ 国家节点，随时随地畅游'
  },
  {
    icon: TrendingUp,
    title: '稳定可靠',
    desc: '99.9% 在线率，7x24 技术支持'
  }
]

const stats = [
  { value: '50+', label: '全球节点' },
  { value: '99.9%', label: '在线率' },
  { value: '10K+', label: '活跃用户' },
  { value: '24/7', label: '技术支持' }
]
</script>

<template>
  <div class="min-h-screen">
    <div class="fixed right-4 top-4 z-50"><ThemeLangToggle /></div>
    <!-- Hero Section -->
    <section class="relative overflow-hidden px-4 py-20 lg:py-32">
      <div class="absolute inset-0 -z-10">
        <div class="absolute left-1/4 top-0 h-96 w-96 rounded-full bg-indigo/20 blur-3xl"></div>
        <div class="absolute bottom-0 right-1/4 h-96 w-96 rounded-full bg-cyan/20 blur-3xl"></div>
      </div>

      <div class="mx-auto max-w-6xl text-center">
        <div class="inline-flex items-center gap-2 rounded-full border border-border bg-surface px-4 py-2 text-xs uppercase tracking-[0.2em] text-muted">
          <span class="h-2 w-2 animate-pulse rounded-full bg-lime"></span>
          V2Board · Halo Design System
        </div>

        <h1 class="gradient-animate mt-8 bg-gradient-to-r from-indigo via-cyan to-lime bg-clip-text text-5xl font-bold leading-tight text-transparent md:text-7xl lg:text-8xl">
          Interfaces fade.
          <br />
          Information
          <br />
          becomes the light.
        </h1>

        <p class="mx-auto mt-8 max-w-2xl text-lg leading-8 text-muted lg:text-xl">
          基于 V2Board 官方 API 构建的现代化暗色用户中心<br />
          极简、克制、清晰的设计语言
        </p>

        <div class="mt-10 flex flex-col justify-center gap-4 sm:flex-row">
          <button class="halo-btn halo-btn-primary text-base" @click="router.push('/register')">
            立即开始
            <ArrowRight :size="18" />
          </button>
          <button class="halo-btn halo-btn-ghost text-base" @click="router.push('/login')">
            登录账户
          </button>
        </div>

        <div class="mt-16 grid grid-cols-2 gap-6 sm:grid-cols-4">
          <div v-for="stat in stats" :key="stat.label" class="text-center">
            <div class="mono text-3xl font-bold text-indigo lg:text-4xl">{{ stat.value }}</div>
            <div class="mt-2 text-sm text-muted">{{ stat.label }}</div>
          </div>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="px-4 py-20">
      <div class="mx-auto max-w-6xl">
        <div class="text-center">
          <div class="text-xs uppercase tracking-[0.26em] text-muted">Features</div>
          <h2 class="mt-3 text-3xl font-bold lg:text-4xl">为什么选择我们</h2>
        </div>

        <div class="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <div v-for="feature in features" :key="feature.title" class="halo-card group p-6">
            <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-indigo/20 to-cyan/20">
              <component :is="feature.icon" :size="24" class="text-indigo" />
            </div>
            <h3 class="mt-4 text-lg font-semibold">{{ feature.title }}</h3>
            <p class="mt-2 text-sm leading-relaxed text-muted">{{ feature.desc }}</p>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="px-4 py-20">
      <div class="halo-card gradient-animate mx-auto max-w-4xl bg-gradient-to-r from-indigo/10 via-cyan/10 to-lime/10 p-12 text-center">
        <h2 class="text-3xl font-bold lg:text-4xl">准备好开始了吗？</h2>
        <p class="mt-4 text-lg text-muted">立即注册，享受高速稳定的网络服务</p>
        <button class="halo-btn halo-btn-primary mt-8 text-base" @click="router.push('/register')">
          免费注册
          <ArrowRight :size="18" />
        </button>
      </div>
    </section>

    <!-- Footer -->
    <footer class="border-t border-border px-4 py-8">
      <div class="mx-auto max-w-6xl text-center text-sm text-muted">
        <p>© 2024 Cloud Console. Powered by V2Board.</p>
      </div>
    </footer>
  </div>
</template>
