<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import HaloStatCard from '@/components/HaloStatCard.vue'
import CopyButton from '@/components/CopyButton.vue'
import { useUserStore } from '@/stores/user'
import { formatMoney, formatDate } from '@/utils/format'
import { formatTraffic, getTrafficPercent, getUsedTraffic } from '@/utils/traffic'
import { TrendingUp, TrendingDown, Activity } from 'lucide-vue-next'
import { usePreferencesStore } from '@/stores/preferences'

const user = useUserStore()
const preferences = usePreferencesStore()

const upload = computed(() => Number(user.subscribe?.u || 0))
const download = computed(() => Number(user.subscribe?.d || 0))
const used = computed(() => getUsedTraffic(user.subscribe?.u, user.subscribe?.d))
const total = computed(() => Number(user.subscribe?.transfer_enable || user.info?.transfer_enable || 0))
const percent = computed(() => getTrafficPercent(used.value, total.value))
const subscribeUrl = computed(() => user.subscribe?.subscribe_url || '')

const trafficTrend = ref([
  { date: '01-15', upload: 2.3, download: 8.5 },
  { date: '01-16', upload: 3.1, download: 12.2 },
  { date: '01-17', upload: 2.8, download: 9.8 },
  { date: '01-18', upload: 4.2, download: 15.6 },
  { date: '01-19', upload: 3.5, download: 11.3 },
  { date: '01-20', upload: 5.1, download: 18.9 },
  { date: '01-21', upload: 4.8, download: 16.2 }
])

const maxTraffic = computed(() => {
  const allValues = trafficTrend.value.flatMap(d => [d.upload, d.download])
  return Math.max(...allValues)
})

onMounted(() => user.fetchUser())
</script>

<template>
  <div class="space-y-3 lg:space-y-4">
    <!-- 第一行：账户概览 -->
    <section class="grid grid-cols-2 gap-2.5 sm:gap-3 xl:grid-cols-4">
      <HaloStatCard
        :title="preferences.t('accountBalance')"
        :value="formatMoney(user.info?.balance)"
        color="indigo"
        sub="Balance"
      />

      <HaloStatCard
        :title="preferences.t('commissionBalance')"
        :value="formatMoney(user.info?.commission_balance)"
        color="lime"
        sub="Commission"
      />

      <HaloStatCard
        :title="preferences.t('usedTraffic')"
        :value="formatTraffic(used)"
        color="cyan"
        :sub="`${percent.toFixed(1)}%`"
      />

      <HaloStatCard
        :title="preferences.t('expireTime')"
        :value="formatDate(user.subscribe?.expired_at || user.info?.expired_at)"
        color="amber"
        sub="Expire"
      />
    </section>

    <!-- 流量趋势图 + 订阅信息 -->
    <section class="grid gap-3 lg:gap-4 xl:grid-cols-[1.6fr_1fr]">
      <div class="halo-card p-4 lg:p-5">
        <div class="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between lg:mb-5">
          <div>
            <div class="text-[10px] uppercase tracking-[0.26em] text-muted">Traffic Trend</div>
            <h2 class="mt-1 text-lg font-semibold lg:text-xl">
              {{ preferences.t('trafficTrend') }}
            </h2>
          </div>

          <div class="flex items-center gap-2 self-start rounded-full border border-border bg-elevated/50 px-2.5 py-1.5 text-xs sm:self-auto">
            <Activity :size="13" class="text-cyan" />
            <span class="text-muted">{{ preferences.t('recent7Days') }}</span>
          </div>
        </div>

        <div class="space-y-2.5 lg:space-y-3">
          <div v-for="item in trafficTrend" :key="item.date" class="flex items-center gap-2 sm:gap-3">
            <div class="mono w-10 text-[10px] text-muted sm:w-12 sm:text-xs">
              {{ item.date }}
            </div>

            <div class="flex flex-1 gap-1 sm:gap-1.5">
              <div class="relative h-7 flex-1 overflow-hidden rounded-lg bg-elevated sm:h-8">
                <div
                  class="h-full rounded-lg bg-gradient-to-r from-indigo/80 to-indigo transition-all"
                  :style="{ width: (item.upload / maxTraffic * 100) + '%' }"
                ></div>
                <div class="absolute inset-0 flex items-center justify-center text-[9px] font-medium sm:text-[10px]">
                  <TrendingUp :size="9" class="mr-0.5 sm:mr-1" />
                  {{ item.upload }}
                </div>
              </div>

              <div class="relative h-7 flex-1 overflow-hidden rounded-lg bg-elevated sm:h-8">
                <div
                  class="h-full rounded-lg bg-gradient-to-r from-cyan/80 to-cyan transition-all"
                  :style="{ width: (item.download / maxTraffic * 100) + '%' }"
                ></div>
                <div class="absolute inset-0 flex items-center justify-center text-[9px] font-medium sm:text-[10px]">
                  <TrendingDown :size="9" class="mr-0.5 sm:mr-1" />
                  {{ item.download }}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="mt-3 flex items-center justify-center gap-4 text-xs lg:mt-4">
          <div class="flex items-center gap-1.5">
            <div class="h-2 w-2 rounded-full bg-indigo"></div>
            <span class="text-muted">{{ preferences.t('upload') }} GB</span>
          </div>

          <div class="flex items-center gap-1.5">
            <div class="h-2 w-2 rounded-full bg-cyan"></div>
            <span class="text-muted">{{ preferences.t('download') }} GB</span>
          </div>
        </div>
      </div>

      <div class="halo-card p-4 lg:p-5">
        <div class="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between lg:mb-4">
          <div>
            <div class="text-[10px] uppercase tracking-[0.26em] text-muted">Subscription</div>
            <h2 class="mt-1 text-lg font-semibold lg:text-xl">
              {{ preferences.t('subscription') }}
            </h2>
          </div>

          <CopyButton :text="subscribeUrl" />
        </div>

        <div class="rounded-xl border border-border bg-canvas/50 p-3">
          <div class="break-all text-[11px] leading-relaxed text-muted sm:text-xs">
            {{ subscribeUrl || preferences.t('noSubscribe') }}
          </div>
        </div>

        <div class="mt-3 lg:mt-4">
          <div class="mb-2 flex justify-between text-xs">
            <span class="text-muted">{{ preferences.t('usedTraffic') }}</span>
            <span class="mono text-[11px] sm:text-xs">
              {{ formatTraffic(used) }} / {{ formatTraffic(total) }}
            </span>
          </div>

          <div class="h-2.5 overflow-hidden rounded-full bg-elevated">
            <div
              class="h-full rounded-full bg-gradient-to-r from-indigo to-cyan transition-all"
              :style="{ width: percent + '%' }"
            ></div>
          </div>
        </div>

        <div class="mt-3 space-y-2 text-xs lg:mt-4 lg:space-y-2.5">
          <div class="flex justify-between border-b border-border/70 pb-2 lg:pb-2.5">
            <span class="text-muted">{{ preferences.t('email') }}</span>
            <span class="truncate pl-3 text-[11px] sm:text-xs">
              {{ user.info?.email || '-' }}
            </span>
          </div>

          <div class="flex justify-between border-b border-border/70 pb-2 lg:pb-2.5">
            <span class="text-muted">UUID</span>
            <span class="mono truncate pl-3 text-[9px] sm:text-[10px]">
              {{ user.info?.uuid || user.subscribe?.uuid || '-' }}
            </span>
          </div>

          <div class="flex justify-between">
            <span class="text-muted">Plan ID</span>
            <span class="text-[11px] sm:text-xs">
              {{ user.subscribe?.plan_id || user.info?.plan_id || '-' }}
            </span>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>
