import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useAppStore } from '@/stores/app'

const routes: RouteRecordRaw[] = [
  {
    path: '/landing',
    component: () => import('@/views/Landing.vue')
  },

  {
    path: '/',
    redirect: '/landing'
  },
  {
    path: '/login',
    component: () => import('@/views/auth/Login.vue'),
    meta: { guest: true }
  },
  {
    path: '/register',
    component: () => import('@/views/auth/Register.vue'),
    meta: { guest: true }
  },
  {
    path: '/forgot',
    component: () => import('@/views/auth/Forgot.vue'),
    meta: { guest: true }
  },
  {
    path: '/',
    component: () => import('@/layouts/ConsoleLayout.vue'),
    meta: { auth: true },
    children: [
      {
        path: 'dashboard',
        component: () => import('@/views/Dashboard.vue')
      },
      {
        path: 'subscribe',
        component: () => import('@/views/Subscribe.vue')
      },
      {
        path: 'plans',
        component: () => import('@/views/Plans.vue')
      },
      {
        path: 'nodes',
        component: () => import('@/views/Nodes.vue')
      },
      {
        path: 'orders',
        component: () => import('@/views/Orders.vue')
      },
      {
        path: 'tickets',
        component: () => import('@/views/Tickets.vue')
      },
      {
        path: 'knowledge',
        component: () => import('@/views/Knowledge.vue')
      },
      {
        path: 'invite',
        component: () => import('@/views/Invite.vue')
      },
      {
        path: 'wallet',
        component: () => import('@/views/Wallet.vue')
      },
      {
        path: 'settings',
        component: () => import('@/views/Settings.vue')
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to) => {
  const auth = useAuthStore()
  const app = useAppStore()

  app.startLoading()

  if (to.meta.auth && !auth.isLoggedIn) {
    app.stopLoading()
    return '/login'
  }

  if (to.meta.guest && auth.isLoggedIn) {
    app.stopLoading()
    return '/dashboard'
  }

  return true
})

router.afterEach(() => {
  const app = useAppStore()
  app.stopLoading()
})

router.onError(() => {
  const app = useAppStore()
  app.stopLoading()
})

export default router
