<script setup lang="ts">
import { ref } from 'vue'
import { Languages, Palette, Check } from 'lucide-vue-next'
import { usePreferencesStore } from '@/stores/preferences'
import { themePresets } from '@/config/site'

const preferences = usePreferencesStore()
const open = ref(false)

function selectTheme(name: keyof typeof themePresets) {
  preferences.setTheme(name)
  open.value = false
}
</script>

<template>
  <div class="relative flex items-center gap-2">
    <button
      class="halo-btn halo-btn-ghost h-10 px-3 text-xs"
      :title="preferences.t('theme')"
      @click="open = !open"
    >
      <Palette :size="15" />
      <span class="hidden sm:inline">{{ preferences.currentTheme.name }}</span>
    </button>

    <button
      class="halo-btn halo-btn-ghost h-10 px-3 text-xs"
      :title="preferences.t('language')"
      @click="preferences.toggleLang()"
    >
      <Languages :size="15" />
      <span>{{ preferences.lang === 'zh' ? '中' : 'EN' }}</span>
    </button>

    <Transition
      enter-active-class="transition duration-150 ease-out"
      enter-from-class="opacity-0 translate-y-1 scale-95"
      enter-to-class="opacity-100 translate-y-0 scale-100"
      leave-active-class="transition duration-100 ease-in"
      leave-from-class="opacity-100 translate-y-0 scale-100"
      leave-to-class="opacity-0 translate-y-1 scale-95"
    >
      <div
        v-if="open"
        class="absolute right-0 top-12 z-[100] w-48 rounded-2xl border border-border bg-surface/95 p-2 shadow-halo backdrop-blur-xl"
      >
        <button
          v-for="(theme, key) in themePresets"
          :key="key"
          class="flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-sm transition hover:bg-white/5"
          :class="preferences.themeName === key ? 'text-onSurface' : 'text-muted'"
          @click="selectTheme(key as keyof typeof themePresets)"
        >
          <span class="flex items-center gap-2">
            <span
              class="h-3 w-3 rounded-full"
              :style="{ background: theme.primary }"
            ></span>
            {{ theme.name }}
          </span>

          <Check v-if="preferences.themeName === key" :size="15" class="text-indigo" />
        </button>
      </div>
    </Transition>
  </div>
</template>
