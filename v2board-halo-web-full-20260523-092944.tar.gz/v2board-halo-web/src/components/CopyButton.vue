<script setup lang="ts">
import { ref } from 'vue'
import { Copy, Check } from 'lucide-vue-next'

const props = defineProps<{ text?: string }>()
const copied = ref(false)

async function copyText() {
  if (!props.text) return
  await navigator.clipboard.writeText(props.text)
  copied.value = true
  setTimeout(() => copied.value = false, 1400)
}
</script>

<template>
  <button class="halo-btn halo-btn-primary text-xs sm:text-sm" @click="copyText">
    <Check v-if="copied" :size="14" />
    <Copy v-else :size="14" />
    <span class="hidden sm:inline">{{ copied ? '已复制' : '复制' }}</span>
    <span class="sm:hidden">{{ copied ? '✓' : '复制' }}</span>
  </button>
</template>
