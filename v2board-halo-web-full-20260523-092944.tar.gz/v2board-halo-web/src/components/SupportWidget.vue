<script setup lang="ts">
import { ref } from 'vue'
import { Headphones, X } from 'lucide-vue-next'
import { siteConfig } from '@/config/site'

const open = ref(false)

function openLink() {
  if (siteConfig.support.type === 'telegram' && siteConfig.support.telegram) {
    window.open(siteConfig.support.telegram, '_blank')
    return
  }

  if (siteConfig.support.link) {
    window.open(siteConfig.support.link, '_blank')
  }
}
</script>

<template>
  <div v-if="siteConfig.support.enabled" :class="siteConfig.support.position === 'left' ? 'left-4' : 'right-4'" class="fixed bottom-4 z-[90]">
    <div v-if="open" class="mb-3 w-[280px] rounded-2xl border border-border bg-surface/95 p-4 shadow-halo backdrop-blur">
      <div class="mb-3 flex items-center justify-between">
        <div>
          <div class="text-sm font-semibold">{{ siteConfig.support.title }}</div>
          <div class="text-xs text-muted">{{ siteConfig.support.subtitle }}</div>
        </div>
        <button class="rounded-lg p-1 hover:bg-white/5" @click="open = false">
          <X :size="16" />
        </button>
      </div>

      <template v-if="siteConfig.support.type === 'qr' && siteConfig.support.qrImage">
        <img :src="siteConfig.support.qrImage" alt="support qr" class="mx-auto rounded-xl" />
      </template>

      <template v-else>
        <button class="halo-btn halo-btn-primary w-full" @click="openLink">
          {{ siteConfig.support.buttonText }}
        </button>
      </template>
    </div>

    <button
      class="halo-btn halo-btn-primary h-12 w-12 rounded-full shadow-glow"
      @click="open = !open"
    >
      <Headphones :size="18" />
    </button>
  </div>
</template>
