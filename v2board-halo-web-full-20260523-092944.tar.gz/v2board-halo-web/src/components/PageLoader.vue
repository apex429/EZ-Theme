<script setup lang="ts">
import { computed } from 'vue'
import { useAppStore } from '@/stores/app'

const app = useAppStore()
const show = computed(() => app.pageLoading)
</script>

<template>
  <Transition
    enter-active-class="transition-opacity duration-150"
    leave-active-class="transition-opacity duration-200"
    enter-from-class="opacity-0"
    leave-to-class="opacity-0"
  >
    <div
      v-if="show"
      class="pointer-events-none fixed left-1/2 top-5 z-[120] -translate-x-1/2"
    >
      <div class="relative h-9 w-9">
        <div class="absolute inset-0 rounded-full border-2 border-indigo/20"></div>
        <div class="halo-spinner absolute inset-0 rounded-full border-2 border-transparent border-t-indigo border-r-cyan"></div>
        <div class="absolute inset-3 rounded-full bg-gradient-to-br from-indigo to-cyan opacity-80 blur-sm"></div>
      </div>
    </div>
  </Transition>
</template>
