<script setup lang="ts">
import { CheckCircle, XCircle, Info, AlertTriangle, X } from 'lucide-vue-next'
import { useFeedbackStore } from '@/stores/feedback'

const feedback = useFeedbackStore()

const iconMap = {
  success: CheckCircle,
  error: XCircle,
  info: Info,
  warning: AlertTriangle
}

const colorMap = {
  success: 'border-lime/40 bg-lime/10 text-lime',
  error: 'border-magenta/40 bg-magenta/10 text-magenta',
  info: 'border-cyan/40 bg-cyan/10 text-cyan',
  warning: 'border-amber/40 bg-amber/10 text-amber'
}
</script>

<template>
  <!-- Toast -->
  <div class="fixed right-4 top-4 z-[200] flex w-[calc(100vw-32px)] max-w-sm flex-col gap-2">
    <TransitionGroup
      enter-active-class="transition duration-200 ease-out"
      enter-from-class="translate-x-4 opacity-0 scale-95"
      enter-to-class="translate-x-0 opacity-100 scale-100"
      leave-active-class="transition duration-150 ease-in"
      leave-from-class="translate-x-0 opacity-100 scale-100"
      leave-to-class="translate-x-4 opacity-0 scale-95"
    >
      <div
        v-for="item in feedback.toasts"
        :key="item.id"
        class="rounded-2xl border p-4 shadow-halo backdrop-blur-xl"
        :class="colorMap[item.type]"
      >
        <div class="flex items-start gap-3">
          <component :is="iconMap[item.type]" :size="18" class="mt-0.5 shrink-0" />
          <div class="min-w-0 flex-1 text-sm leading-6">
            {{ item.message }}
          </div>
          <button class="rounded-lg p-1 hover:bg-white/5" @click="feedback.removeToast(item.id)">
            <X :size="14" />
          </button>
        </div>
      </div>
    </TransitionGroup>
  </div>

  <!-- Confirm -->
  <Teleport to="body">
    <Transition
      enter-active-class="transition-opacity duration-150"
      leave-active-class="transition-opacity duration-150"
      enter-from-class="opacity-0"
      leave-to-class="opacity-0"
    >
      <div
        v-if="feedback.confirmState.show"
        class="fixed inset-0 z-[190] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      >
        <div class="halo-card w-full max-w-md p-5">
          <div class="flex items-start justify-between gap-4">
            <div>
              <div class="text-[10px] uppercase tracking-[0.24em] text-muted">
                Confirm
              </div>
              <h3 class="mt-1 text-lg font-semibold">
                {{ feedback.confirmState.title }}
              </h3>
            </div>

            <button class="rounded-lg p-2 hover:bg-white/5" @click="feedback.confirmCancel">
              <X :size="18" />
            </button>
          </div>

          <p class="mt-4 text-sm leading-7 text-muted">
            {{ feedback.confirmState.message }}
          </p>

          <div class="mt-5 flex gap-2">
            <button class="halo-btn halo-btn-ghost flex-1" @click="feedback.confirmCancel">
              {{ feedback.confirmState.cancelText }}
            </button>
            <button class="halo-btn halo-btn-primary flex-1" @click="feedback.confirmOk">
              {{ feedback.confirmState.confirmText }}
            </button>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>
