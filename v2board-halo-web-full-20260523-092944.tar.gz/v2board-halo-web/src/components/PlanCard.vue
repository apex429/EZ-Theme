<script setup lang="ts">
import { Check } from 'lucide-vue-next'
import type { Plan } from '@/api/plan'
import { formatMoney } from '@/utils/format'
import { formatTraffic } from '@/utils/traffic'

const props = defineProps<{
  plan: Plan
  layout?: 'card' | 'list' | 'compact'
}>()

const emit = defineEmits<{
  select: [plan: Plan]
}>()

function priceOf(plan: Plan) {
  return plan.month_price || plan.quarter_price || plan.half_year_price || plan.year_price || plan.onetime_price || 0
}

const features = [
  { label: '流量', value: formatTraffic(props.plan.transfer_enable) },
  { label: '限速', value: props.plan.speed_limit ? `${props.plan.speed_limit} Mbps` : '不限速' },
  { label: '设备', value: props.plan.capacity_limit || '不限' }
]
</script>

<template>
  <!-- 卡片布局 -->
  <div v-if="layout === 'card' || !layout" class="halo-card group relative overflow-hidden p-5 lg:p-6">
    <div class="absolute right-0 top-0 h-32 w-32 translate-x-8 -translate-y-8 rounded-full bg-gradient-to-br from-indigo/20 to-cyan/20 blur-3xl"></div>
    
    <div class="relative">
      <div class="text-[10px] uppercase tracking-[0.26em] text-muted">Plan #{{ plan.id }}</div>
      <h3 class="mt-2 text-xl font-semibold lg:text-2xl">{{ plan.name }}</h3>
      
      <div class="mono mt-4 flex items-baseline gap-1">
        <span class="text-3xl font-bold lg:text-4xl">{{ formatMoney(priceOf(plan)) }}</span>
        <span class="text-sm text-muted">/月起</span>
      </div>

      <div class="mt-5 space-y-2.5">
        <div v-for="feature in features" :key="feature.label" class="flex items-center gap-2 text-sm">
          <Check :size="16" class="text-lime" />
          <span class="text-muted">{{ feature.label }}：</span>
          <span>{{ feature.value }}</span>
        </div>
      </div>

      <div v-if="plan.content" class="mt-4 text-xs leading-relaxed text-muted" v-html="plan.content"></div>

      <button 
        class="halo-btn halo-btn-primary mt-6 w-full"
        @click="emit('select', plan)"
      >
        选择套餐
      </button>
    </div>
  </div>

  <!-- 列表布局 -->
  <div v-else-if="layout === 'list'" class="halo-card flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between lg:p-5">
    <div class="flex-1">
      <h3 class="text-lg font-semibold lg:text-xl">{{ plan.name }}</h3>
      <div class="mt-2 flex flex-wrap gap-3 text-xs text-muted">
        <span v-for="feature in features" :key="feature.label">
          {{ feature.label }}: {{ feature.value }}
        </span>
      </div>
    </div>
    
    <div class="flex items-center gap-4">
      <div class="mono text-right">
        <div class="text-2xl font-bold lg:text-3xl">{{ formatMoney(priceOf(plan)) }}</div>
        <div class="text-xs text-muted">/月起</div>
      </div>
      <button class="halo-btn halo-btn-primary" @click="emit('select', plan)">
        选择
      </button>
    </div>
  </div>

  <!-- 紧凑布局 -->
  <div v-else-if="layout === 'compact'" class="halo-card p-4">
    <div class="flex items-start justify-between">
      <div>
        <h3 class="font-semibold">{{ plan.name }}</h3>
        <div class="mono mt-1 text-lg font-bold">{{ formatMoney(priceOf(plan)) }}</div>
      </div>
      <button class="halo-btn halo-btn-primary text-xs" @click="emit('select', plan)">
        选择
      </button>
    </div>
    <div class="mt-3 text-xs text-muted">
      {{ formatTraffic(plan.transfer_enable) }} · {{ plan.speed_limit ? `${plan.speed_limit} Mbps` : '不限速' }}
    </div>
  </div>
</template>
