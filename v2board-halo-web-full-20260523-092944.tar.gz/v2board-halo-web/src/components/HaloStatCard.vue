<script setup lang="ts">
defineProps<{
  title: string
  value: string | number
  sub?: string
  color?: 'indigo' | 'cyan' | 'lime' | 'amber' | 'magenta'
}>()

const colorMap = {
  indigo: 'border-t-indigo text-indigo',
  cyan: 'border-t-cyan text-cyan',
  lime: 'border-t-lime text-lime',
  amber: 'border-t-amber text-amber',
  magenta: 'border-t-magenta text-magenta'
}
</script>

<template>
  <div class="halo-card border-t-2 p-3.5 sm:p-4 lg:p-5" :class="colorMap[color || 'indigo']">
    <div class="text-[9px] tracking-[0.24em] text-muted uppercase sm:text-[10px]">{{ title }}</div>
    <div class="mono mt-2.5 text-xl font-semibold text-onSurface sm:text-2xl lg:mt-4 lg:text-3xl">{{ value }}</div>
    <div v-if="sub" class="mt-2.5 inline-flex rounded-full bg-white/5 px-2.5 py-1 text-[10px] lg:mt-4 lg:text-xs" :class="colorMap[color || 'indigo']">
      {{ sub }}
    </div>
  </div>
</template>
