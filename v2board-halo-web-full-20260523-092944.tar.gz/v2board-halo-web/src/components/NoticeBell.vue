<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { Bell, X } from 'lucide-vue-next'
import { fetchNoticeApi } from '@/api/notice'

const open = ref(false)
const notices = ref<any[]>([])
const loading = ref(false)

const count = computed(() => notices.value.length)

function normalize(data: any) {
  if (Array.isArray(data)) return data
  if (Array.isArray(data?.data)) return data.data
  if (Array.isArray(data?.notices)) return data.notices
  if (Array.isArray(data?.notice)) return data.notice
  return []
}

async function load() {
  loading.value = true
  try {
    const res = await fetchNoticeApi()
    notices.value = normalize(res.data)
  } catch {
    notices.value = []
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<template>
  <div class="relative">
    <button class="halo-btn halo-btn-ghost h-10 px-3 text-xs" @click="open = true">
      <Bell :size="15" />
      <span v-if="count" class="ml-1 rounded-full bg-magenta px-1.5 py-0.5 text-[10px] text-white">
        {{ count }}
      </span>
    </button>

    <Teleport to="body">
      <Transition
        enter-active-class="transition-opacity duration-150"
        leave-active-class="transition-opacity duration-150"
        enter-from-class="opacity-0"
        leave-to-class="opacity-0"
      >
        <div v-if="open" class="fixed inset-0 z-[130] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div class="halo-card max-h-[80vh] w-full max-w-2xl overflow-hidden">
            <div class="flex items-center justify-between border-b border-border p-4">
              <div>
                <div class="text-[10px] uppercase tracking-[0.24em] text-muted">Notice</div>
                <h2 class="mt-1 text-lg font-semibold">公告</h2>
              </div>

              <button class="rounded-lg p-2 hover:bg-white/5" @click="open = false">
                <X :size="18" />
              </button>
            </div>

            <div class="max-h-[60vh] overflow-y-auto p-4">
              <div v-if="loading" class="py-8 text-center text-muted">加载中...</div>

              <div v-else-if="!notices.length" class="py-8 text-center text-muted">
                暂无公告
              </div>

              <div v-else class="space-y-3">
                <article
                  v-for="item in notices"
                  :key="item.id || item.title"
                  class="rounded-2xl border border-border bg-canvas/40 p-4"
                >
                  <h3 class="font-semibold">
                    {{ item.title || item.subject || '公告' }}
                  </h3>
                  <div
                    class="mt-3 text-sm leading-7 text-muted"
                    v-html="item.content || item.message || item.body || item.description || ''"
                  ></div>
                </article>
              </div>
            </div>
          </div>
        </div>
      </Transition>
    </Teleport>
  </div>
</template>
