export const siteConfig = {
  apiBaseUrl: 'https://2983839.xyz',
  siteName: 'Cloud Console',
  logoText: 'Cloud',

theme: {
    primary: '#FF6B8B',
    primaryGlow: 'rgba(255, 107, 139, 0.26)',
    accent: '#FFD700',
    surface: '#1C1417',
    canvas: '#0F0A0B'
  },

  login: {
    title: 'Interfaces fade.',
    highlight: 'Information',
    subtitle: 'becomes the light.',
    description: '基于V2面板构建的用户中心。',
    backgroundImage: 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=1600&auto=format&fit=crop',
    backgroundMask: 'rgba(10,11,15,.62)'
  },

  landing: {
    heroBadge: 'V2Board · Halo Design System',
    heroTitleTop: 'Interfaces fade.',
    heroTitleMid: 'Information',
    heroTitleBottom: 'becomes the light.',
    heroDescription: '尊贵----没有尊贵的感觉就像---没有尊贵一样。'
  },

  community: {
    enabled: true,
    title: '官方社群',
    telegramGroup: 'https://t.me/your_group',
    telegramChannel: 'https://t.me/your_channel',
    docsUrl: 'https://cloud.5858188.xyz',
    statusUrl: 'https://cloud.5858188.xyz'
  },

  support: {
    enabled: true,
    title: '在线客服',
    subtitle: '需要帮助？联系我们',
    type: 'link', 
    /**
     * 可选:
     * link      -> 跳转链接
     * telegram  -> Telegram 链接
     * qr        -> 展示二维码图片
     */

    buttonText: '联系客服',
    link: 'https://t.me/your_support',
    telegram: 'https://t.me/your_support',
    qrImage: '',
    position: 'right'
  }
}

export const themePresets = {
  halo: {
    name: 'Halo',
    primary: '#5B6BFF',
    primaryGlow: 'rgba(91,107,255,.28)',
    accent: '#3DD7E5',
    surface: '#14151C',
    canvas: '#0A0B0F'
  },
  rose: {
    name: 'Rose',
    primary: '#FF6B8B',
    primaryGlow: 'rgba(255,107,139,.28)',
    accent: '#FFD166',
    surface: '#141014',
    canvas: '#0F0A0B'
  },
  emerald: {
    name: 'Emerald',
    primary: '#2BED8C',
    primaryGlow: 'rgba(43,237,140,.24)',
    accent: '#3DD7E5',
    surface: '#101714',
    canvas: '#070B09'
  },
  violet: {
    name: 'Violet',
    primary: '#8B5CF6',
    primaryGlow: 'rgba(139,92,246,.28)',
    accent: '#EC4899',
    surface: '#15111F',
    canvas: '#0B0812'
  }
}

export const messages = {
  zh: {
    dashboard: '仪表盘',
    subscribe: '订阅',
    plans: '套餐',
    nodes: '节点',
    orders: '订单',
    tickets: '工单',
    knowledge: '文档',
    invite: '邀请',
    wallet: '钱包',
    settings: '设置',
    buyPlan: '购买套餐',
    mySubscribe: '订阅',
    logout: '退出',
    logoutFull: '退出登录',
    workspace: '工作台',
    cloudConsole: '控制台',
    theme: '主题',
    language: '语言',
    loading: '加载中',
    accountBalance: '账户余额',
    commissionBalance: '佣金余额',
    usedTraffic: '已用流量',
    expireTime: '到期时间',
    trafficTrend: '流量趋势',
    recent7Days: '最近 7 天',
    upload: '上传',
    download: '下载',
    subscription: '订阅',
    copy: '复制',
    copied: '已复制',
    resetSubscribe: '重置订阅',
    importClient: '一键导入客户端',
    email: '邮箱',
    password: '密码',
    login: '登录',
    loginAccount: '登录账户',
    register: '注册账号',
    forgotPassword: '忘记密码',
    createAccount: '注册账号',
    inviteCode: '邀请码',
    emailCode: '邮箱验证码，如未开启可留空',
    submit: '提交',
    backLogin: '返回登录',
    noSubscribe: '暂无订阅链接'
  },
  en: {
    dashboard: 'Dashboard',
    subscribe: 'Subscribe',
    plans: 'Plans',
    nodes: 'Nodes',
    orders: 'Orders',
    tickets: 'Tickets',
    knowledge: 'Docs',
    invite: 'Invite',
    wallet: 'Wallet',
    settings: 'Settings',
    buyPlan: 'Buy Plan',
    mySubscribe: 'Subscribe',
    logout: 'Logout',
    logoutFull: 'Logout',
    workspace: 'Workspace',
    cloudConsole: 'Console',
    theme: 'Theme',
    language: 'Language',
    loading: 'Loading',
    accountBalance: 'Balance',
    commissionBalance: 'Commission',
    usedTraffic: 'Used Traffic',
    expireTime: 'Expire Time',
    trafficTrend: 'Traffic Trend',
    recent7Days: 'Recent 7 Days',
    upload: 'Upload',
    download: 'Download',
    subscription: 'Subscription',
    copy: 'Copy',
    copied: 'Copied',
    resetSubscribe: 'Reset Subscribe',
    importClient: 'Import Client',
    email: 'Email',
    password: 'Password',
    login: 'Login',
    loginAccount: 'Sign in',
    register: 'Register',
    forgotPassword: 'Forgot Password',
    createAccount: 'Create Account',
    inviteCode: 'Invite Code',
    emailCode: 'Email Code, leave blank if disabled',
    submit: 'Submit',
    backLogin: 'Back to login',
    noSubscribe: 'No subscription URL'
  }
}
