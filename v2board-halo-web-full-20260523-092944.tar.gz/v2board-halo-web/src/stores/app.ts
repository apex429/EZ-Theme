import { defineStore } from 'pinia'

export const useAppStore = defineStore('app', {
  state: () => ({
    pageLoading: false
  }),

  actions: {
    startLoading() {
      this.pageLoading = true
    },

    stopLoading() {
      setTimeout(() => {
        this.pageLoading = false
      }, 220)
    }
  }
})
