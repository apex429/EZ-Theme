import { defineStore } from 'pinia'
import { loginApi } from '@/api/auth'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem('token') || '',
    authData: localStorage.getItem('auth_data') || '',
    isAdmin: Number(localStorage.getItem('is_admin') || 0)
  }),

  getters: {
    isLoggedIn: (state) => Boolean(state.authData || state.token)
  },

  actions: {
    async login(email: string, password: string) {
      const res = await loginApi({ email, password })
      const data = res.data

      this.token = data.token
      this.authData = data.auth_data
      this.isAdmin = data.is_admin

      localStorage.setItem('token', data.token)
      localStorage.setItem('auth_data', data.auth_data)
      localStorage.setItem('is_admin', String(data.is_admin))

      return data
    },

    logout() {
      this.token = ''
      this.authData = ''
      this.isAdmin = 0
      localStorage.removeItem('token')
      localStorage.removeItem('auth_data')
      localStorage.removeItem('is_admin')
    }
  }
})
