import { defineStore } from 'pinia'
import { messages, siteConfig, themePresets } from '@/config/site'

type ThemeName = keyof typeof themePresets
type Lang = keyof typeof messages

function hexToRgb(hex: string) {
  let value = hex.replace('#', '').trim()

  if (value.length === 3) {
    value = value.split('').map((x) => x + x).join('')
  }

  const num = parseInt(value, 16)
  const r = (num >> 16) & 255
  const g = (num >> 8) & 255
  const b = num & 255

  return `${r} ${g} ${b}`
}

function applyThemeVars(themeName: ThemeName) {
  const theme = themePresets[themeName] || themePresets.halo
  const root = document.documentElement

  root.style.setProperty('--indigo', theme.primary)
  root.style.setProperty('--cyan', theme.accent)
  root.style.setProperty('--surface', theme.surface)
  root.style.setProperty('--canvas', theme.canvas)
  root.style.setProperty('--primary-glow', theme.primaryGlow)

  root.style.setProperty('--indigo-rgb', hexToRgb(theme.primary))
  root.style.setProperty('--cyan-rgb', hexToRgb(theme.accent))
  root.style.setProperty('--surface-rgb', hexToRgb(theme.surface))
  root.style.setProperty('--canvas-rgb', hexToRgb(theme.canvas))

  root.style.setProperty('--elevated-rgb', '30 32 41')
  root.style.setProperty('--lime-rgb', '43 237 140')
  root.style.setProperty('--amber-rgb', '245 213 71')
  root.style.setProperty('--magenta-rgb', '255 58 92')
  root.style.setProperty('--border-rgb', '42 45 56')
  root.style.setProperty('--muted-rgb', '154 163 178')
  root.style.setProperty('--on-surface-rgb', '242 244 248')
}

export const usePreferencesStore = defineStore('preferences', {
  state: () => ({
    themeName: (localStorage.getItem('theme_name') || 'halo') as ThemeName,
    lang: (localStorage.getItem('lang') || 'zh') as Lang
  }),

  getters: {
    currentTheme(state) {
      return themePresets[state.themeName] || themePresets.halo
    },

    currentLang(state) {
      return messages[state.lang] || messages.zh
    }
  },

  actions: {
    init() {
      const exists = themePresets[this.themeName]
      if (!exists) this.themeName = 'halo'

      applyThemeVars(this.themeName)
      document.documentElement.lang = this.lang === 'zh' ? 'zh-CN' : 'en'

      document.body.style.overflow = ''
      document.documentElement.style.overflow = ''
    },

    setTheme(themeName: ThemeName) {
      this.themeName = themeName
      localStorage.setItem('theme_name', themeName)
      applyThemeVars(themeName)
    },

    nextTheme() {
      const keys = Object.keys(themePresets) as ThemeName[]
      const index = keys.indexOf(this.themeName)
      const next = keys[(index + 1) % keys.length]
      this.setTheme(next)
    },

    toggleLang() {
      this.lang = this.lang === 'zh' ? 'en' : 'zh'
      localStorage.setItem('lang', this.lang)
      document.documentElement.lang = this.lang === 'zh' ? 'zh-CN' : 'en'
    },

    t(key: keyof typeof messages.zh) {
      return this.currentLang[key] || messages.zh[key] || key
    }
  }
})
