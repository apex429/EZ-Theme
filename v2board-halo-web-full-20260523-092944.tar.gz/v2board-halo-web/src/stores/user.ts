import { defineStore } from 'pinia'
import { getSubscribeApi, getUserInfoApi, type SubscribeInfo, type UserInfo } from '@/api/user'

export const useUserStore = defineStore('user', {
  state: (): {
    info: UserInfo | null
    subscribe: SubscribeInfo | null
    loading: boolean
  } => ({
    info: null,
    subscribe: null,
    loading: false
  }),

  actions: {
    async fetchUser() {
      this.loading = true
      try {
        const [infoRes, subRes] = await Promise.allSettled([
          getUserInfoApi(),
          getSubscribeApi()
        ])

        if (infoRes.status === 'fulfilled') {
          this.info = infoRes.value.data
        }

        if (subRes.status === 'fulfilled') {
          this.subscribe = subRes.value.data
        }
      } finally {
        this.loading = false
      }
    }
  }
})
