import { defineStore } from 'pinia'

type ToastType = 'success' | 'error' | 'info' | 'warning'

interface ToastItem {
  id: number
  type: ToastType
  message: string
}

interface ConfirmState {
  show: boolean
  title: string
  message: string
  confirmText: string
  cancelText: string
  resolve?: (value: boolean) => void
}

export const useFeedbackStore = defineStore('feedback', {
  state: () => ({
    toasts: [] as ToastItem[],
    confirmState: {
      show: false,
      title: '',
      message: '',
      confirmText: '确定',
      cancelText: '取消',
      resolve: undefined
    } as ConfirmState
  }),

  actions: {
    toast(type: ToastType, message: string) {
      const id = Date.now() + Math.random()
      this.toasts.push({ id, type, message })

      setTimeout(() => {
        this.toasts = this.toasts.filter(item => item.id !== id)
      }, 2600)
    },

    success(message: string) {
      this.toast('success', message)
    },

    error(message: string) {
      this.toast('error', message)
    },

    info(message: string) {
      this.toast('info', message)
    },

    warning(message: string) {
      this.toast('warning', message)
    },

    confirm(options: {
      title?: string
      message: string
      confirmText?: string
      cancelText?: string
    }) {
      return new Promise<boolean>((resolve) => {
        this.confirmState = {
          show: true,
          title: options.title || 'Confirm',
          message: options.message,
          confirmText: options.confirmText || '确定',
          cancelText: options.cancelText || '取消',
          resolve
        }
      })
    },

    confirmOk() {
      this.confirmState.show = false
      this.confirmState.resolve?.(true)
    },

    confirmCancel() {
      this.confirmState.show = false
      this.confirmState.resolve?.(false)
    },

    removeToast(id: number) {
      this.toasts = this.toasts.filter(item => item.id !== id)
    }
  }
})
